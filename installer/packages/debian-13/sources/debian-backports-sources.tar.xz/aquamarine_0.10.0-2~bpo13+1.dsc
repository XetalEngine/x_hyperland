-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: aquamarine
Binary: libaquamarine-dev, libaquamarine9
Architecture: any
Version: 0.10.0-2~bpo13+1
Maintainer: Debian Hyprland Maintainers <team+hyprland@tracker.debian.org>
Uploaders:  Alan M Varghese (NyxTrail) <alan@digistorm.in>, Carl Keinath <carl.keinath@gmail.com>, Chow Loong Jin <hyperair@debian.org>
Homepage: https://wiki.hyprland.org/Hypr-Ecosystem/aquamarine/
Standards-Version: 4.7.2
Vcs-Browser: https://salsa.debian.org/hyprland-team/aquamarine
Vcs-Git: https://salsa.debian.org/hyprland-team/aquamarine.git
Build-Depends: cmake, debhelper-compat (= 13), hwdata, hyprwayland-scanner (>= 0.4.5), libdisplay-info-dev, libdrm-dev, libegl-dev, libegl1-mesa-dev, libgbm-dev, libgles-dev, libhyprutils-dev (>= 0.10.4), libinput-dev (>= 1.26.0), libpixman-1-dev, libseat-dev (>= 0.8.0), libudev-dev, libwayland-dev, pkgconf, wayland-protocols
Package-List:
 libaquamarine-dev deb libdevel optional arch=any
 libaquamarine9 deb libs optional arch=any
Checksums-Sha1:
 847e54ece57cf0680720da1042072767d4f8aa25 89829 aquamarine_0.10.0.orig.tar.gz
 fbd6f5b78284be3c43b0b49312445f6547f874f8 3156 aquamarine_0.10.0-2~bpo13+1.debian.tar.xz
Checksums-Sha256:
 227b49c73bce14c706ee57ee6909d5fb15522de5f359c99b98aff3a4f3b04d1a 89829 aquamarine_0.10.0.orig.tar.gz
 27c35a1dc49523ebd6245998aa366b615f1d0555da9060f4c7cba9b32f5d746c 3156 aquamarine_0.10.0-2~bpo13+1.debian.tar.xz
Files:
 763078d3f48400f40b54842f0cbcdf99 89829 aquamarine_0.10.0.orig.tar.gz
 bb6e7cbe6da5dfaf8956cde8f867ccf1 3156 aquamarine_0.10.0-2~bpo13+1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtgob82PcExn/Co6JEWhSvN91FcAFAmnRfRcACgkQEWhSvN91
FcCeog/+K9SMwvTSRXWA9ODDp9xoki3K2m4hYGFuaDpBoKxJ9f1r19vV+66MudQg
WNSElw81+DaoUmOiVmjjGlXpJmOIxyIPXQvviEhHdkP5r5E6r72vWTwCEFDY09W+
u9/7uLj73vkOhgDAEbbDRhSolYByqlyyK98YkZWGdoytRU4sa1G0Mb38d37ufGZQ
+7vSvB03IwucvC3dArfAMr4S/H/EdO1CDGvR80jZWaGgwmhuqwlqOx6JHzvYL0L+
2qByA/qgds9f4tNxm7WlPfmezE72uUcf6Pk9rnAVI07jGE+CAK4aAYGdJPm4aLIF
wrzj/Lp1kHWdwBHrJ59frgrZQ/IB5diIb0wGCQ6rymnruQt0oSweQoZpmNa7QqEU
Bu8xsjzWlODXmQ0fC4asyQpBfYPBwASfpPGHZQ6p86aQe46hL+3eXo0QojHXjZwW
rX6fn7f3U71VDALGH/T0B8KdgRSA0O4YauO073eP6pY/SgCu8vARgK5FHM7oj7Fb
GgcTWiKdRJ+sU+lM/a6vQgH0R4pyokPhxVeD7YDGS8ZFsmNkxhlKy+wvK13CkGtt
ED0wopA0UMoFRS1AgCcb7/jBp20PokTxIjvzBry61QjrIEiDikzHsLin7ESN2KdD
ZQ0bvFUr4pOhQfPQZtlGtK7RwFAbbMqI8beFIK0rbQDWy8NA0ho=
=WG7p
-----END PGP SIGNATURE-----
