-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: hyprtoolkit
Binary: libhyprtoolkit-dev, libhyprtoolkit5
Architecture: any
Version: 0.5.3-1~bpo13+1
Maintainer: Debian Hyprland Maintainers <team+hyprland@tracker.debian.org>
Uploaders:  Carl Keinath <carl.keinath@gmail.com>, Chow Loong Jin <hyperair@debian.org>,
Homepage: https://github.com/hyprwm/hyprtoolkit
Standards-Version: 4.7.3
Vcs-Browser: https://salsa.debian.org/hyprland-team/hyprtoolkit
Vcs-Git: https://salsa.debian.org/hyprland-team/hyprtoolkit.git
Build-Depends: debhelper-compat (= 13), cmake, pkgconf, libegl-dev, libgles-dev, hyprwayland-scanner (>= 0.4.0), libwayland-dev, wayland-protocols, libhyprutils-dev (>= 0.11.0), libhyprlang-dev (>= 0.6.0), libpixman-1-dev, libdrm-dev, libgbm-dev, libxkbcommon-dev, libpango1.0-dev, libcairo2-dev, libiniparser-dev, libhyprgraphics-dev (>= 0.5.0), libaquamarine-dev (>= 0.10.0), libgtest-dev
Package-List:
 libhyprtoolkit-dev deb libdevel optional arch=any
 libhyprtoolkit5 deb libs optional arch=any
Checksums-Sha1:
 d77e60252b2b87cc6428660b885f17704e770360 574820 hyprtoolkit_0.5.3.orig.tar.gz
 2f594c631159ddbab585abfa7c758b60535fbfd0 4308 hyprtoolkit_0.5.3-1~bpo13+1.debian.tar.xz
Checksums-Sha256:
 65117d0954206910f7f422c4af633f6c396d591b60cadf2ca53b84a06f670548 574820 hyprtoolkit_0.5.3.orig.tar.gz
 26fe6d944b5d9ee796d771c39450903f9f4fd0cd649d3fd0125d21f95a430ae8 4308 hyprtoolkit_0.5.3-1~bpo13+1.debian.tar.xz
Files:
 ae1e408e64de78d47c5a539a492f816c 574820 hyprtoolkit_0.5.3.orig.tar.gz
 16cebe1f1beeb43099105fc38d9cc2a6 4308 hyprtoolkit_0.5.3-1~bpo13+1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtgob82PcExn/Co6JEWhSvN91FcAFAmnSB0oACgkQEWhSvN91
FcDkyhAAkV9YWpkSMIocbpiPHPT2zm7EIvATbLTuuzmc4ISB4eAMT/9Z/ec7v94C
Q/HGZ8l40heG3NBA4IcB6XN2ShfUu0IEVhq0Z00KsMkL8H259kQC1cBzMvDfLm2P
VoTIh4ZskBGYIj1yWDVbkOFP6TZ1oZkPHNwYmFuKnVhr5hBAsZiUqhLVKiCR+mRV
VxWfvfCGa4R1pEaotU3muCscNoL80aW2HZMFBhhttScAbg9CjIGswn14hyNo+gQm
s1AQTLBYrNyEkwn90ZnPOvRh7PQhygPKD8sGRKdLyR5JOZscbqdhWlxheTAuc36y
OHv5wMQ/LAZ6K30tCpyuBJCuCCNzZhe0fvLCb17AcEcJoGdUvbK4i9+EjRRkM4Rh
MEhulOyILona1xUKHg36lhO82vejFrcaAChiGlPdzTwh7y8sCYvx8K+khShZt9YS
+hkgfMG52RYs+WdUGfVOpUw+cXjBz4N1pw73+2AkvXfq1fNbGmS0K6pyHWP8GGXk
n7zDSMNSXhGiqGvrFXdYWNJsHS4/M7fXuVh3Xy4l3GCwbSQyoLYSZKDfUh8jOZiF
/Vo35Psgn2dLMcHZKqG3E9/b6/W5d2TXcD0DICGt1yTva2T60hlCnq/cAKO6Pl/1
YDZpO7vhwHgyX3UDwp60nPXDBH7sGNDdJb4mhEnC01HvKAmHm5o=
=b4TN
-----END PGP SIGNATURE-----
