-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: hyprlock
Binary: hyprlock
Architecture: any
Version: 0.9.6-1~bpo13+1
Maintainer: Debian Hyprland Maintainers <team+hyprland@tracker.debian.org>
Uploaders:  Carl Keinath <carl.keinath@gmail.com>, Chow Loong Jin <hyperair@debian.org>, Alex Myczko <tar@debian.org>,
Homepage: https://github.com/hyprwm/hyprlock
Standards-Version: 4.7.4
Vcs-Browser: https://salsa.debian.org/hyprland-team/hyprlock
Vcs-Git: https://salsa.debian.org/hyprland-team/hyprlock.git
Build-Depends: debhelper-compat (= 13), cmake, hyprwayland-scanner (>= 0.4.4), libcairo2-dev, libdrm-dev, libegl-dev, libgbm-dev, libgles2-mesa-dev, libhyprgraphics-dev (>= 0.1.6), libhyprlang-dev (>= 0.6.0), libhyprutils-dev (>= 0.11.0), libpam0g-dev, libpango1.0-dev, libsdbus-c++-dev (>= 2.0.0), libwayland-dev, libwayland-egl-backend-dev, libxkbcommon-dev, pkgconf, wayland-protocols
Package-List:
 hyprlock deb x11 optional arch=any
Checksums-Sha1:
 5e2655da15c3fdb438aa419fb57b1042c2436f94 85300 hyprlock_0.9.6.orig.tar.gz
 295febdcf4621e6849791a9f7c057faa5d0a0fef 4284 hyprlock_0.9.6-1~bpo13+1.debian.tar.xz
Checksums-Sha256:
 998b2bd84cdc6c925422ff5fbde03b73c6f1143d7074abde098244c8e4f4ed19 85300 hyprlock_0.9.6.orig.tar.gz
 2f48365289c30379879783b95faeb9b288bc9218ed336b4ee6f880e4d6234805 4284 hyprlock_0.9.6-1~bpo13+1.debian.tar.xz
Files:
 1500a1c8d1701048e2aeb9834453130b 85300 hyprlock_0.9.6.orig.tar.gz
 509c76b0bfcd657a5c518d9b52bfa00e 4284 hyprlock_0.9.6-1~bpo13+1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtgob82PcExn/Co6JEWhSvN91FcAFAmqMOpgACgkQEWhSvN91
FcCY+w/9FyXCg5ela6iKpsnRUjUR5uqGP7F2DIJm5t89Vrnf8rEMcmXyfEtdu3cc
1vwVLNEHscEFEBkNN8URyIrLxJyMIVHBCY3TJKKDHkWMsCEUPeIIt5GNee/sCC2r
QCLPoeyn6oYM76kwh/lc30z/CSDqD5iPeTGhsovmDf0dcUjw2plhAw4ajKaxhmKT
f9t0tHey4dmDG9Wxn/pXcyuGJJBLQ52ri1+hM70JcMU30mafNXMhDE7RZhWCVPNi
cFiNclGM5YM58El1t/l/2H8IyHiTM3GQRdaYTYBbVrhUivsuYYEiYgWTcpyljGab
fXwF7vBe89fwIx8XkxxWmcP597ksiXrhiqTfx7+wD8OukBUT6DpiEV9B4R84licI
ZKpWSe+xwy3h+c1u/ATjdwCoa6c54C3ou2P+DsEHjAI09aFmRleIKVxWlt6Fdk0I
V9SX7cScN2rQZsK3Iyn4NJ52qF9+zR5EWlsVyoG7WOm++kudDBDqjdmbuz8bUVng
g3Grz0LJ0KGAMrTKw3qM3Iy3b1Wgk+Fd3Nrr0eoVWGIgySLWNW2sfC+/V4OaapoV
wDDbyxQD9pOUmX6YyZzxro/epejy6pqAu2fT/2IZ9Oqfgnb4VRcbGniArizkK4/u
beyk0GpiY2ZnbfMXnZ2GjNnsI32U7bl8FamxEZ2vmtEbYfs0mjU=
=O8f4
-----END PGP SIGNATURE-----
