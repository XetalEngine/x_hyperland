-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: hyprutils
Binary: libhyprutils-dev, libhyprutils12
Architecture: any
Version: 0.13.1-2~bpo13+1
Maintainer: Debian Hyprland Maintainers <team+hyprland@tracker.debian.org>
Uploaders:  Alan M Varghese (NyxTrail) <alan@digistorm.in>, Carl Keinath <carl.keinath@gmail.com>, Chow Loong Jin <hyperair@debian.org>
Homepage: https://github.com/hyprwm/hyprutils
Standards-Version: 4.7.4
Vcs-Browser: https://salsa.debian.org/hyprland-team/hyprutils
Vcs-Git: https://salsa.debian.org/hyprland-team/hyprutils.git
Testsuite: autopkgtest
Testsuite-Triggers: @builddeps@, libgtest-dev
Build-Depends: debhelper-compat (= 13), cmake, libpixman-1-dev, pkgconf
Package-List:
 libhyprutils-dev deb libdevel optional arch=any
 libhyprutils12 deb libs optional arch=any
Checksums-Sha1:
 6f09e5bb0f58de34680ce951b1a8748a56aeda7f 60811 hyprutils_0.13.1.orig.tar.gz
 378a8626ca41bb53ec221181d7f54556cb0db6cc 3660 hyprutils_0.13.1-2~bpo13+1.debian.tar.xz
Checksums-Sha256:
 a096db4e34a9104d2e115352f90aba01a2b784ae2063671a9845d153b096de19 60811 hyprutils_0.13.1.orig.tar.gz
 9519fd5f5906d702ab6ff529dc42b3e7cc011773260075b09705af8239d74793 3660 hyprutils_0.13.1-2~bpo13+1.debian.tar.xz
Files:
 d579618a11a203caa9de6a728750ecff 60811 hyprutils_0.13.1.orig.tar.gz
 c3bfd5216c0c6a801e309a27f0ce82c0 3660 hyprutils_0.13.1-2~bpo13+1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtgob82PcExn/Co6JEWhSvN91FcAFAmocNlsACgkQEWhSvN91
FcC+zRAAg1A/8E8H+ZkR8pgc9RP9fcrRCtPWHq+FjDAl31iVdhGm5Np3Jqu+eSQS
3b5mvzm8ovvcNLa0tjNmbAv49V+2jIfjzxIw9/M6RfFDIte827QEuQzgewJVykTh
R0OkbOr0rL4s1+ky+YUyj3aDR+5EUnLcsuUgXWdV1ZKWGed//fKL4/mV2NL2MNOw
//HEDfk2kfjii5FV5h8ymRo5uV0p3tjtMHFiUmWC+Sn/h5wrKSglH0wQm9Lj9/IC
GpGPO32lT+lUy8L+afjW0fkyTpbcOVTnin6XLKPENf4EjiXC2vTEjP4Z8ZedlqF+
TMJUZJxUV1cTZFhGh/QFbN7aBOE4N7mcIX3kW74tzzPi8y8cBjcFW5WVYN073CAD
URprZkPIumYnTMLiL1+J6AWnEFO1BZ9qp9HHGQ9kWdeJWs3QVscTrcM4R6L9nVwd
Z0q+SO6fgYSQv6o1h5wG4HemLdPbQB4FvTHEzqLbOLfCManmLg6fWbW9Sqwee3Y6
iG692wwOp6BqGa1ILTnz9zC1H8kjc8bHdAH/275QzmBNxpJOrge9Qq5JUZY81roB
TeXqbnHxTmXeH7VCXnou9BRK4Fi86vHjGGo/QO5jrverPMcEL+MQZJkJpFeHAL/e
39F00W+EhkLFqlwQiiT6cGBR/qWqHBWIcJJsztA3peHvUqxP+VU=
=XqTn
-----END PGP SIGNATURE-----
