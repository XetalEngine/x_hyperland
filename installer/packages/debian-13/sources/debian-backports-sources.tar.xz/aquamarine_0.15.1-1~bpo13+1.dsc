-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: aquamarine
Binary: libaquamarine-dev, libaquamarine14
Architecture: any
Version: 0.15.1-1~bpo13+1
Maintainer: Debian Hyprland Maintainers <team+hyprland@tracker.debian.org>
Uploaders:  Alan M Varghese (NyxTrail) <alan@digistorm.in>, Carl Keinath <carl.keinath@gmail.com>, Chow Loong Jin <hyperair@debian.org>, Alex Myczko <tar@debian.org>,
Homepage: https://wiki.hyprland.org/Hypr-Ecosystem/aquamarine/
Standards-Version: 4.7.4
Vcs-Browser: https://salsa.debian.org/hyprland-team/aquamarine
Vcs-Git: https://salsa.debian.org/hyprland-team/aquamarine.git
Build-Depends: debhelper-compat (= 13), cmake, hwdata, hyprwayland-scanner (>= 0.4.5), libdisplay-info-dev, libdrm-dev, libegl-dev, libegl1-mesa-dev, libgbm-dev, libgles-dev, libhyprutils-dev (>= 0.10.4), libinput-dev (>= 1.26.0), libpixman-1-dev, libseat-dev (>= 0.8.0), libudev-dev, libwayland-dev, pkgconf, wayland-protocols
Package-List:
 libaquamarine-dev deb libdevel optional arch=any
 libaquamarine14 deb libs optional arch=any
Checksums-Sha1:
 95b020797b6aa741bfbe2d5ca27899cbde71482f 123378 aquamarine_0.15.1.orig.tar.gz
 e331a9e56bc88708fecf47ae5cd535a87e37c611 3376 aquamarine_0.15.1-1~bpo13+1.debian.tar.xz
Checksums-Sha256:
 5de0842f2ccb8b242baa801f553e8cdc7689ef7b882675d1b671f77928225857 123378 aquamarine_0.15.1.orig.tar.gz
 46c03da6d68aa81743dbe00f2e506a0df9d77fd8819486b33ded215fd2f5a9f9 3376 aquamarine_0.15.1-1~bpo13+1.debian.tar.xz
Files:
 0417e043c24e30d1c485c43c6c213047 123378 aquamarine_0.15.1.orig.tar.gz
 a847d09b68b043cbbe76f254d1f025b1 3376 aquamarine_0.15.1-1~bpo13+1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtgob82PcExn/Co6JEWhSvN91FcAFAmq8JbAACgkQEWhSvN91
FcCwyxAAhsf1FG5HEZU+DHTQdLgZmGXYKiJPPfdddN+LUJUbLb/xiX5ndCPIwFZC
QACfBQZt5Zd7jd+ZqeDPJBRgNrZzF2YwpI5OUALKqIh/LSYW4sOfK52gUD4U4+p0
q0Wy75PGFJMgXbKb57JjWRIvIFyFZSWEQq7nHPTPMg+tbuqfwA8DDcHebNtH+vAP
pczAyFeDTcZOx0k3vGZUQf0oPCYqBvoIIw/5Xboj9xsXGHp2vvSgIK37HRJQOZuz
+3iIjcKmMwRsNshnmZLiEICpua2TbAXvlgQzSb+34aH5Ri7mBdnCXXL2SEahJyMR
B4rZpKqFJlTRcPRogk9oSdFl4VgjnziJAsLpsqxtr6+dx1eXuW8jjNhVh3+Ye1Lx
Sr8U4Ketwqj8YgDqb88TYseiZQtJyOYxvH+ElNoKYJOP5Prmm22RwQ17f6unIkS7
uML3EIRVA3nhnQIWFFXqCadpkE9w5kFOd9MMGcqmbWb6zL864QsXRcPNoMj2n0rP
mdpG8VryxZmGef1+RJOhJvVkEa3HM/TcxMZh2SNAfexjMdlUXjxHjrH1kQxgA/9z
YIyeriAerxA2kSk7bNYqi93LlZEXcPbWa8ABeiIIJ31vw7bzEpGOa3zhQbdtuXZe
5kFIx2ZrCFdjn1eA/Mjj5gLqDDEI/Pw1G+SKqOV9rgHkBxfmcCc=
=+BMl
-----END PGP SIGNATURE-----
