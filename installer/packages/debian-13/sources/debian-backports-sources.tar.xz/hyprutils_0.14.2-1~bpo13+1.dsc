-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: hyprutils
Binary: libhyprutils-dev, libhyprutils13
Architecture: any
Version: 0.14.2-1~bpo13+1
Maintainer: Debian Hyprland Maintainers <team+hyprland@tracker.debian.org>
Uploaders:  Alan M Varghese (NyxTrail) <alan@digistorm.in>, Carl Keinath <carl.keinath@gmail.com>, Chow Loong Jin <hyperair@debian.org>, Alex Myczko <tar@debian.org>,
Homepage: https://github.com/hyprwm/hyprutils
Standards-Version: 4.7.4
Vcs-Browser: https://salsa.debian.org/hyprland-team/hyprutils
Vcs-Git: https://salsa.debian.org/hyprland-team/hyprutils.git
Testsuite: autopkgtest
Testsuite-Triggers: @builddeps@, libgtest-dev
Build-Depends: debhelper-compat (= 13), cmake, libpixman-1-dev, pkgconf
Package-List:
 libhyprutils-dev deb libdevel optional arch=any
 libhyprutils13 deb libs optional arch=any
Checksums-Sha1:
 e2a9d4ed80ad9fa6b71d49f590da1cc39a1361ef 81747 hyprutils_0.14.2.orig.tar.gz
 16ecdf713b1f1351b26f4c5dbb7175a4fd16b515 3716 hyprutils_0.14.2-1~bpo13+1.debian.tar.xz
Checksums-Sha256:
 50b8dc764a3ecbf7507872d90ce141543cafcb9050a2fc8d0bed0bdade73a56a 81747 hyprutils_0.14.2.orig.tar.gz
 669ce8936ea778a52bbad8f2b0ea0aefa4f312a0281292bbb6b76f55b64211d2 3716 hyprutils_0.14.2-1~bpo13+1.debian.tar.xz
Files:
 7efa4480b591b5ec8cc1e2fa6e157402 81747 hyprutils_0.14.2.orig.tar.gz
 61a53837b8d54fdceee1305812011ace 3716 hyprutils_0.14.2-1~bpo13+1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtgob82PcExn/Co6JEWhSvN91FcAFAmq9JxoACgkQEWhSvN91
FcDiAw//U/2CEc4ZODyyofUuNWs+f0hWqRtWnNSy9QRM/RyclbdNpyyvbqWZ6n+w
xt9ZMGYJO0q8f1n4mxC1gp0Ua/sm5RyiyxAlKlgBPuIkCOgzDMcuENrUijT3rvlp
8AhZXRzIR5A3hjVw9Yv8HBuov5B3Kp0KColoiCsykFovEDM4UWCXBLcIXRWu65s3
VB1Y0N12wcPR0DM1VDz06LeafomEByPl4+2+k0+goy+hsRqal5g4yQm+3uTkWdUR
ZTvAJfpM+fwIkK6BCXtRFb6FL/gshpgbGIA6lNctA/Deg5s4wN4Q98hnJsJGVe5b
D//0+cz0T8EYu8CVVlcwN5MSve3c6hL9nHg0VTreWB8fG5pixV/yA5I/LrzeUNkc
WlLwaUGydUfAfFLGPfL+lGhAisQCo1j22evJ2d/nSTqLgdsYC0u9qxbXEqV1spOC
PuZrLfMAzzsRw0e+cn9WWGT18NvGxW2uB3dQNcPYNNTDIK30AJpCHaQIg1p1GeDp
t5OtzBvqLJ8rtE5WdsmSS4XBL6ONWUEKfhvfT7BwryZxbonyum4KeHQzXnxwnGxE
uE3ruxbgfxtTcmIFCxjFJZVXCw0xWxO1noR32jOmjoqWI710jrEGAj+tQL25ZGhE
dEqGZfLowB5cM80qfB9smoWpQH00bOIPM7PeA374S7mjKwxpAqM=
=pFY3
-----END PGP SIGNATURE-----
