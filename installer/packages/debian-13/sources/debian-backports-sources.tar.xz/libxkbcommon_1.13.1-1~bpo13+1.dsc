-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: libxkbcommon
Binary: libxkbcommon0, libxkbcommon0-udeb, libxkbcommon-dev, libxkbcommon-doc, libxkbcommon-tools, libxkbcommon-x11-0, libxkbcommon-x11-dev, libxkbregistry0, libxkbregistry-dev
Architecture: any all
Version: 1.13.1-1~bpo13+1
Maintainer: Debian X Strike Force <debian-x@lists.debian.org>
Uploaders: Michael Stapelberg <stapelberg@debian.org>
Homepage: https://www.xkbcommon.org/
Standards-Version: 4.6.1
Vcs-Browser: https://salsa.debian.org/xorg-team/lib/libxkbcommon
Vcs-Git: https://salsa.debian.org/xorg-team/lib/libxkbcommon.git
Testsuite: autopkgtest
Testsuite-Triggers: build-essential, pkg-config
Build-Depends: debhelper-compat (= 13), bison, dh-exec, doxygen, flex, graphviz, meson, pkgconf, quilt, libwayland-dev [linux-any], libxcb-xkb-dev, libxml2-dev, wayland-protocols [linux-any], x11-xkb-utils <!nocheck>, x11proto-dev, xkb-data <!nocheck>, xvfb <!nocheck>
Package-List:
 libxkbcommon-dev deb libdevel optional arch=any
 libxkbcommon-doc deb doc optional arch=all
 libxkbcommon-tools deb graphics optional arch=any
 libxkbcommon-x11-0 deb libs optional arch=any
 libxkbcommon-x11-dev deb libdevel optional arch=any
 libxkbcommon0 deb libs optional arch=any
 libxkbcommon0-udeb udeb debian-installer optional arch=any
 libxkbregistry-dev deb libdevel optional arch=any
 libxkbregistry0 deb libs optional arch=any
Checksums-Sha1:
 56ad7224bf61d2f7ae3ce92c99ee86b452147368 1234757 libxkbcommon_1.13.1.orig.tar.gz
 2e2c64b1d8c75a05f0e0993391823e94db0ab06a 8716 libxkbcommon_1.13.1-1~bpo13+1.debian.tar.xz
Checksums-Sha256:
 6802621c81b674e468d2346a8f6d9a48ba5c154b72434a1c9e1a3eaa29f36fb5 1234757 libxkbcommon_1.13.1.orig.tar.gz
 a2c53030f5390c90058a51948d5f13badf38594a07e91515edb6c7b1b1fca362 8716 libxkbcommon_1.13.1-1~bpo13+1.debian.tar.xz
Files:
 2974945e8655285fa8bf65a0c250cb29 1234757 libxkbcommon_1.13.1.orig.tar.gz
 05294474c289be6b033386bb1fc7cb61 8716 libxkbcommon_1.13.1-1~bpo13+1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtgob82PcExn/Co6JEWhSvN91FcAFAmnT6C0ACgkQEWhSvN91
FcAP7g//aONPt1i6a92CTym/Uq6f3f63JtmxyvMg0BCkK8hImz+bjGuL7D/bF75b
gNA1upeCaQla/pSjRYkN65Ec3vMwPRO5wAXLy6dMhs7CgG4Pd484AGolidBEcfm/
9Tk194xf5PSril0iSH/5D064hHGii2lXxoDjSp3yZHkikYww1jEKRDDuEo/IqLfU
8m6ggYm2stFiniM6yIN9B4hzXePHmIOWszxRusdWvcGS9/rwKxk7UgREDKqgSoLb
P2bb0ZCBB0eDr5FiA1meYHCbdY+486w7dkzGqIynDCyLXZS40aK5esVu5xN9WLUE
AHETxkv/5wKmpNwL5KYBed3rxbBg7DQ+L2AYsQ5Is+Anpfhz7IkfA3yLG8AMLgt1
gkcOAXE9vvSggNiSoZmiC9euTpjhGJGmp1xBLa1jd/ljZY/vNlaNW2c6hh+VFJW7
rXGI8QsJcZMas/mNMByuPwGn2r5uLtTuGDj6zp8m0HFOcsNE4FqO2kwm3EHRiUZd
2/5w72wIFEkmDC7AxFAQd0JY6zX0fBqepYAPWvSiK/9qd8myp6+CNIPojtDnLJT0
E9gYzMicgYR+oKyYunjsnnoYDjjx6we2dl8j+sFKxr2Oeq7xEuD30HkXVhPT8XHh
ON6cSGLb1bWkiJ7wWkFlShvl5QrqofyEbo1HA/5d/OOH4kMc+gM=
=6jXc
-----END PGP SIGNATURE-----
