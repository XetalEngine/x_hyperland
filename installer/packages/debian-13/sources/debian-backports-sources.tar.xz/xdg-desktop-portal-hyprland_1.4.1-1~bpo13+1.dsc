-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: xdg-desktop-portal-hyprland
Binary: xdg-desktop-portal-hyprland
Architecture: any
Version: 1.4.1-1~bpo13+1
Maintainer: Debian Hyprland Maintainers <team+hyprland@tracker.debian.org>
Uploaders:  Carl Keinath <carl.keinath@gmail.com>, Chow Loong Jin <hyperair@debian.org>, Alex Myczko <tar@debian.org>,
Homepage: https://github.com/hyprwm/xdg-desktop-portal-hyprland
Standards-Version: 4.7.4
Vcs-Browser: https://salsa.debian.org/hyprland-team/xdg-desktop-portal-hyprland
Vcs-Git: https://salsa.debian.org/hyprland-team/xdg-desktop-portal-hyprland.git
Build-Depends: debhelper-compat (= 13), cmake (>= 3.19), hyprland-protocols (>= 0.6.3), hyprwayland-scanner (>= 0.4.2), libdrm-dev, libgbm-dev, libhyprlang-dev, libhyprutils-dev, libpipewire-0.3-dev, libsdbus-c++-dev (>= 2.0), libspa-0.2-dev, libwayland-dev, pkgconf, qt6-base-dev, uuid-dev, wayland-protocols
Package-List:
 xdg-desktop-portal-hyprland deb x11 optional arch=any
Checksums-Sha1:
 05d786e0adb2d2f95e7882b09ef2c16d2ce60cf5 60238 xdg-desktop-portal-hyprland_1.4.1.orig.tar.gz
 c540af8f1b9917fb3878d2a047e9600c6926fe7b 4136 xdg-desktop-portal-hyprland_1.4.1-1~bpo13+1.debian.tar.xz
Checksums-Sha256:
 4bfd5284c85da7b5e935c3e56840ff7d9cce28345b0b2b92ada9adb6709bd29b 60238 xdg-desktop-portal-hyprland_1.4.1.orig.tar.gz
 c503e2ad26361a502a9a8213db528c8a4092a39740757371c8fca4b9b7a85562 4136 xdg-desktop-portal-hyprland_1.4.1-1~bpo13+1.debian.tar.xz
Files:
 5582e9118deae12481209e0f5465a5d6 60238 xdg-desktop-portal-hyprland_1.4.1.orig.tar.gz
 a3720a5356b8e2eaf1d2719a2a289433 4136 xdg-desktop-portal-hyprland_1.4.1-1~bpo13+1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtgob82PcExn/Co6JEWhSvN91FcAFAmqMWWAACgkQEWhSvN91
FcDPEhAAnG/UFICHOqY8LA3Rif8RRGPhzzAU+KSEUShkRODhHp6Z8mjHSeU319r5
aDtj1l7Kh8dvxkRgN+S6vQBb8XQ1gajSR1xwnUdY9owpZh4vs+wnPIxCzh35r/gK
eXdCZQe81S2eO+yUEGv/kqcuQH0KXuobWwYb8gDZPVB2ah50cR0hwBbuMOQjcqnx
fwvNol9T/1+64W7+FeGO78rEbVJnYDSZ3h5VWe1wBTFQe2DGjlyFmZbOAr4Nzoiw
3FCw+WBFmDBsfAHgNLiYvbVvdzFDYvTwnVv31u3svLn7/um3mMxuNKW0oa5Ti2mr
ItBYv51QbYxvAo6LQQbZ946jDNHhwkwF2GsVp8yVJdHwk5b5+wKTD+daH7nIncQu
wrpkNMPE69NCA/wTcWhWdR4FsIdD98GKSwJDMKlu0SIwI8INPzvl1HhK+ZmcQg5t
E43OeE5baWy8DZeZzeCrq5ER5Lr9ZEBM5a1enu09ipjdUzI5duo0x1i7ihYb0nvD
ZzYtn7K2TyLOIKLct7RKTvedxMHmCHCmE0MmlxGa72Xfn+3zV4zXxm7lgj70Sl4P
Bg3qMZZ94XSpQ9GSf+GFewNJDUhWRpAM45WmydMdaJNu5gk70pp4j5xV9Z+C+2Oq
Eftyu7kj9aYseo2V/csOdSjyiPFYGZLHvE+z5qrsj0wB+4X1Bes=
=qBuQ
-----END PGP SIGNATURE-----
