-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: hyprutils
Binary: libhyprutils-dev, libhyprutils10
Architecture: any
Version: 0.11.1-1~bpo13+1
Maintainer: Debian Hyprland Maintainers <team+hyprland@tracker.debian.org>
Uploaders:  Alan M Varghese (NyxTrail) <alan@digistorm.in>, Carl Keinath <carl.keinath@gmail.com>, Chow Loong Jin <hyperair@debian.org>
Homepage: https://github.com/hyprwm/hyprutils
Standards-Version: 4.7.3
Vcs-Browser: https://salsa.debian.org/hyprland-team/hyprutils
Vcs-Git: https://salsa.debian.org/hyprland-team/hyprutils.git
Testsuite: autopkgtest
Testsuite-Triggers: @builddeps@, libgtest-dev
Build-Depends: debhelper-compat (= 13), cmake, libpixman-1-dev, pkgconf
Package-List:
 libhyprutils-dev deb libdevel optional arch=any
 libhyprutils10 deb libs optional arch=any
Checksums-Sha1:
 09dad7c7ffcbab3090f87ddf7975f5eaaf0580de 58860 hyprutils_0.11.1.orig.tar.gz
 cf1dedd4336c987fcaaed052fe905ff2e8e91d8b 3572 hyprutils_0.11.1-1~bpo13+1.debian.tar.xz
Checksums-Sha256:
 c2ee480dbf6d342b00b8e7fec3151274d6632e4176d189827a9b58578389f967 58860 hyprutils_0.11.1.orig.tar.gz
 128c09193906c698fd54172ebbb2ef500cd37622eff0d29c203d0397694dc9b1 3572 hyprutils_0.11.1-1~bpo13+1.debian.tar.xz
Files:
 245c062aa8fad5b526a0f66068c76b5d 58860 hyprutils_0.11.1.orig.tar.gz
 4eaf6798c782a594846e7d2df6b1470d 3572 hyprutils_0.11.1-1~bpo13+1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtgob82PcExn/Co6JEWhSvN91FcAFAmnRcbcACgkQEWhSvN91
FcDEWhAAi95P9p5M1LalAFr5dsONk93k1Tzm48KJ47Q8n4D2I+hurmytj+2P1DV3
2944JWHRyUSyv+AbKAaRPmvb0MDY9v1XsJG9lbj9yFgGFq6L6zDb4THrsiWy7S4q
AzJDCeGv6bYw5Wwwt1FpVZycdwbf71KvS2Pi34FGhdP5gEXQ8jOxVKX4xvY+FBZ6
V9BRlbplnRiodJyjUYrRiMndhdT8AGMyspV6XCA/GfiYhk20+HOtyaRLeITAfAg0
EsnqWA3rYja7XI2rv7Z92W0dXMRpcfSyfvozkB6CnXo4g9mtycK4rw6gDSJB/U4q
5A4fgS9vzvpQJllHMZ1jYMQkvvR64XEdl/3DTbWIOTGoEQWECDUNBD8EWauHh+No
jT5zoba++UAatG7mJbLwZQlYRvAqsZeMrmgTec46+1JVWFJsWTg2Aiqhq+q9i3Wt
MF0locUIKY0VV8g/8ytQE4aObOJhxbTknXHnIQCFLRvLOf3AZOMQGvjsvZSywA3/
+FhJYa4msX/nLhIssEHyWVNOplCSNhyp/QDiCvTxe7P/W4LO24BH/xUS+CmzSBvR
cteIbm3xdDQVCTYae8G7bThYymiYcW5ef2ilEivKgIq/mCCPS2lZuRv6Oxo6ChM2
rTixc+GFrTpEmj6Ojc/zIAMSguYZ3k0cj5w5aA/PpYou0U3T+fg=
=Vzle
-----END PGP SIGNATURE-----
