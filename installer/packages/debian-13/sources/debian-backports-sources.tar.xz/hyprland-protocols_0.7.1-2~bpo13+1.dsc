-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: hyprland-protocols
Binary: hyprland-protocols
Architecture: all
Version: 0.7.1-2~bpo13+1
Maintainer: Debian Hyprland Maintainers <team+hyprland@tracker.debian.org>
Uploaders:  Alan M Varghese (NyxTrail) <alan@digistorm.in>, Carl Keinath <carl.keinath@gmail.com>, Chow Loong Jin <hyperair@debian.org>, Alex Myczko <tar@debian.org>,
Homepage: https://github.com/hyprwm/hyprland-protocols
Standards-Version: 4.7.4
Vcs-Browser: https://salsa.debian.org/hyprland-team/hyprland-protocols
Vcs-Git: https://salsa.debian.org/hyprland-team/hyprland-protocols.git
Build-Depends: debhelper-compat (= 13), cmake
Package-List:
 hyprland-protocols deb x11 optional arch=all
Checksums-Sha1:
 c104ca04400ffbc24bb780e7ef30e3bb45f72cf5 11623 hyprland-protocols_0.7.1.orig.tar.gz
 e5bd1f705eacc801d1d3c3047ab4ae2f2cd32a1b 2796 hyprland-protocols_0.7.1-2~bpo13+1.debian.tar.xz
Checksums-Sha256:
 ed69685937af9615a825891bed32f9188b2fd858e4c017d469e1887d076b5a26 11623 hyprland-protocols_0.7.1.orig.tar.gz
 d5407524ce3c1c454a22b9fc837bf120d399506b78fce3d9b435d7f89157ac0f 2796 hyprland-protocols_0.7.1-2~bpo13+1.debian.tar.xz
Files:
 db1fc0d0e15ee823cec1a6941402a3ac 11623 hyprland-protocols_0.7.1.orig.tar.gz
 0dae820332984d2f7832201801b4e396 2796 hyprland-protocols_0.7.1-2~bpo13+1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtgob82PcExn/Co6JEWhSvN91FcAFAmq9JzwACgkQEWhSvN91
FcAnLQ/8CWIyQ3Sw1AnduS/nFBaL0JVCSzIq6hv29Axbik1SOS9f1tUSVGTP+iHV
DeljB17/ImMVqT+bbH/gRj28e/f7sGrQWnbGOASSYEnTqFGRsFpWjySRIv9uXe6t
sCUDyMCe5CvSqK3NSTXG7f8YBjpcRaBgew5B/SdRr433XOSlw++M90XPpP49bN//
7TnU31iqF+UoedyOB7kuQkV/kqoJsOKSS8txAMz/9HxL3rY14yfUuFitChzSorkQ
96Z0DVytkVDpky6rFz28/gisHooIP2XkpyDI0avNcVZgNbC8E14qEljylnQbCd2R
FY9OV0Kxub78rs3Yx/PdRhUtDRRtKJjsVLndr/M9bWhZVf+P3gTS9xRwccgwz/8k
oggxFwULYYhTYEqvfT3zJqgmfaE3qTkc8ks90ew4Gn5AYMrBUHK4llGLHx1v+QjL
8+B+AVsz14WJpj6RSOU6yxpgNsLLxZKC6Nz7BJQz2Osdono+DS56vxdhhJQjqDsa
MvrPT0eJQZRZAxxPQDD4u6ZxshMufn/v9+dQwlRIbHOwHfbRPYUpeVTTrUoyd0j/
rZvSDdKcOAj5pFKCEAKGngdu4lyfqlKfaMKDuZXKTnMmjacwhaAsQ5Ko8KdLjOjh
KXrlfoOtQO72DbTBGgrEV0CnTnX2T1jRoFvLL1uRSKO83+ygiPY=
=Op2T
-----END PGP SIGNATURE-----
