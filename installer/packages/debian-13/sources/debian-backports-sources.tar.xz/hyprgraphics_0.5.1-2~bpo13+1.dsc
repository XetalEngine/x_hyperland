-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: hyprgraphics
Binary: libhyprgraphics-dev, libhyprgraphics4
Architecture: any
Version: 0.5.1-2~bpo13+1
Maintainer: Debian Hyprland Maintainers <team+hyprland@tracker.debian.org>
Uploaders:  Carl Keinath <carl.keinath@gmail.com>, Chow Loong Jin <hyperair@debian.org>, Alan M Varghese (NyxTrail) <alan@digistorm.in>,
Homepage: https://github.com/hyprwm/hyprgraphics
Description: C++ graphics utility library for Hyprland
 Hyprgraphics is a small C++ library with graphics / resource related utilities
 used across the hypr* ecosystem.
Standards-Version: 4.7.4
Vcs-Browser: https://salsa.debian.org/hyprland-team/hyprgraphics
Vcs-Git: https://salsa.debian.org/hyprland-team/hyprgraphics.git
Testsuite: autopkgtest
Testsuite-Triggers: @builddeps@
Build-Depends: debhelper-compat (= 13), cmake, pkgconf, libpixman-1-dev, libcairo2-dev, libdrm-dev, libpango1.0-dev, libhyprutils-dev (>= 0.2.2), libjpeg-dev, libwebp-dev, libmagic-dev, libspng-dev, librsvg2-dev, libjxl-dev, libheif-dev, libgles-dev
Package-List:
 libhyprgraphics-dev deb libdevel optional arch=any
 libhyprgraphics4 deb libs optional arch=any
Checksums-Sha1:
 e83317874a43a5f77089996f7bed22904d8ab38e 460002 hyprgraphics_0.5.1.orig.tar.gz
 54209b4bc7058dd9e6ebb31cf7236deebc557653 4104 hyprgraphics_0.5.1-2~bpo13+1.debian.tar.xz
Checksums-Sha256:
 57268fb39108c161ff83a0d8cab7e5222764794b99f071b28efd809ba85f9ad9 460002 hyprgraphics_0.5.1.orig.tar.gz
 1d59f09cd6bdd0288a0a494839a1f26056fec0905ffe0235b49c1ba3dfa5b6f6 4104 hyprgraphics_0.5.1-2~bpo13+1.debian.tar.xz
Files:
 414c130b40743d2de28709c477df80a4 460002 hyprgraphics_0.5.1.orig.tar.gz
 891f3c818144d156c147b6009dc9bce3 4104 hyprgraphics_0.5.1-2~bpo13+1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtgob82PcExn/Co6JEWhSvN91FcAFAmnvvIcACgkQEWhSvN91
FcDwIg//Q1w9UFiSVfNS4P19F/zNu8MPbfEYWUmqOYUcr+1YoYwvawo1mS/ugJIG
OHVj57woAnVXQAwPtCgF3T1YTZM3mUsT8/0XV1gH0y1862oBb6G5aKV8FyjD1fv0
N2xGZuV6rTPO7MbPDVfCd3l7f/LGCmWpWU/NKlC3Z6zlKtmD+5FNsnKwVAHV88Jj
64TqylHHLsG4YQrfj7/1LS7QZSmzp2wszrHQnUOMeTFGTcYZEWFERrx7sBQjt2J/
WJIpU8TNy60eABpLccgwOMfui//OfXgFGSyW+2fANurV+6q7YjyqM61+LZqIlrDM
SI7uC0ihaXly3Ko5lS1qPTa03TR3NhkBRIeo8huaZqwCoEZAr9qmYFMK4lgUaDOW
+dhFK9rjG/xEqGSFQ3qHv/Mbon6Hc+owRv3BdUIpd5WN5iLgo73dR4uGMb/tsUij
1DESfyiXbHcwSoARTfQPniC8SD1TPSBBExx6N8lsHmDgvAfeZovF2CqVNoG0eOSN
KZw4XVpvxnCdsqgq8GeLn8NeH9Rj0RZeQP/F2JMlD3EuLqGMHy6CqO/l/wRtT3fT
F1gv9k9aWA4xdK93HzT8wKUU5T+/cGF+NII9RkUyfsX0vsraLNpqbr8jLWnvIcMz
+nnB4oh3WQYe1x5Yz3ZL8Tb7OzCaIMGzJoBZR2Md036bRq/iDc4=
=YOpQ
-----END PGP SIGNATURE-----
