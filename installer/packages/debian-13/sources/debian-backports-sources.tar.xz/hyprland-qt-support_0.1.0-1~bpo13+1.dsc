-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: hyprland-qt-support
Binary: qml6-module-org-hyprland-style
Architecture: any
Version: 0.1.0-1~bpo13+1
Maintainer: Debian Hyprland Maintainers <team+hyprland@tracker.debian.org>
Uploaders:  Carl Keinath <carl.keinath@gmail.com>, Chow Loong Jin <hyperair@debian.org>,
Homepage: https://github.com/hyprwm/hyprland-qt-support
Standards-Version: 4.7.2
Vcs-Browser: https://salsa.debian.org/hyprland-team/hyprland-qt-support
Vcs-Git: https://salsa.debian.org/hyprland-team/hyprland-qt-support.git
Build-Depends: debhelper-compat (= 13), cmake, pkgconf, libhyprlang-dev (>= 0.6.0), qt6-base-dev, qt6-declarative-dev, qt6-wayland-dev
Package-List:
 qml6-module-org-hyprland-style deb libs optional arch=any
Checksums-Sha1:
 db6fadd9b3005ff5e304426552428f7b5055585d 12955 hyprland-qt-support_0.1.0.orig.tar.gz
 8eb219545fc9b9f4e0929ae4c8bbba75555178f4 2792 hyprland-qt-support_0.1.0-1~bpo13+1.debian.tar.xz
Checksums-Sha256:
 cac1f980bd088b890097f3f999cfdf03e73ee94c53f3c92d0b3bc23baa9e7b2c 12955 hyprland-qt-support_0.1.0.orig.tar.gz
 c1707da6e8fd1f301db5c508139e166ceb4ab8a3e281fbaf3b9ca9053376c97e 2792 hyprland-qt-support_0.1.0-1~bpo13+1.debian.tar.xz
Files:
 f5f89ff70770e77e106f7455baa1c743 12955 hyprland-qt-support_0.1.0.orig.tar.gz
 50e00b8d4afbe07c059c775dc1f9a16d 2792 hyprland-qt-support_0.1.0-1~bpo13+1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtgob82PcExn/Co6JEWhSvN91FcAFAmnT85wACgkQEWhSvN91
FcC75RAAmdp8FUEJTAvqWFsBQTgq6sGCEniB1z06qcZ7UBZrv2xOOSzL8LephkOl
m7xblp37ysPmSeEZhJgfcTJE3hv+p04UhfjJsmZczjvr9pxS0QPqck246Z+/4+KU
ltNYgZnCScQ+ZnrENhM6f4YQ+Y0r4T19M930Hl0qaX+5kCEfMrr7J9K8BhpsJhXD
P6AospneBn9d8DuDUFcxyJw+rCNCef9vxtSaH6IXCRD4R35shlJ3NyrGKnoZu1Zm
v374zVDKJKMhi59QwpcANelFyqLEnLsAne7gQjAcy7u5Zaa4jJJRPssx5JrYWF5P
Q90PG6TOWasdPOctswKqig3Elo6CsAZIB756FPx9zpDs3EjC2jzVpOctfdkrGK/G
3oT+fCIWVQUf8dOWrzR+YtEYdg86AmCTBRllX0akl4wh6HrTDjiLzmFgZhYcdlDk
v6mFPMBRQRqUgYm1cQ/PXyGgBciAuGdAnjvmGDfb2P6VU0eJknytSdfEn+5ef7kC
SHnb8Tez26k6w8EghOAoN5TNcDyIZo2ZmM+Lpa6jrw1OfGAUmk8P/AWXNUD3Glhw
tapxjgy1Of3D6JmYgLwRF4ovxMOcL9wHHQ5WxLV37YmpOvMV38bSB9l7Wjhq+PAX
c0HuuMCS1/6ChxUk8nDjaxrv6e35Nn7WGmuP69puxYGG45cotok=
=e33c
-----END PGP SIGNATURE-----
