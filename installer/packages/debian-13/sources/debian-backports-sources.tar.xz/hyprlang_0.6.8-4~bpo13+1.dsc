-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: hyprlang
Binary: libhyprlang-dev, libhyprlang2
Architecture: any
Version: 0.6.8-4~bpo13+1
Maintainer: Debian Hyprland Maintainers <team+hyprland@tracker.debian.org>
Uploaders:  Alan M Varghese (NyxTrail) <alan@digistorm.in>, Carl Keinath <carl.keinath@gmail.com>, Chow Loong Jin <hyperair@debian.org>, Alex Myczko <tar@debian.org>,
Homepage: https://github.com/hyprwm/hyprlang/
Standards-Version: 4.7.4
Vcs-Browser: https://salsa.debian.org/hyprland-team/hyprlang
Vcs-Git: https://salsa.debian.org/hyprland-team/hyprlang.git
Testsuite: autopkgtest
Testsuite-Triggers: @builddeps@
Build-Depends: debhelper-compat (= 13), cmake, libhyprutils-dev (>= 0.7.1), pkgconf
Package-List:
 libhyprlang-dev deb libdevel optional arch=any
 libhyprlang2 deb libs optional arch=any
Checksums-Sha1:
 bfbd7981adddec2c869bcd8e3565a9a6f2e0b142 63562 hyprlang_0.6.8.orig.tar.gz
 22264378ed89575008441e55662373a1eac0f55e 3104 hyprlang_0.6.8-4~bpo13+1.debian.tar.xz
Checksums-Sha256:
 d10a0778b646e04d83e8b90cc0f764fb96958c01a15c3c0678d95a40fc647ed5 63562 hyprlang_0.6.8.orig.tar.gz
 dd1b664ccbf521c7da0d52cd6dbc668fddabf2ae88324637b27d65c0fe7cfc47 3104 hyprlang_0.6.8-4~bpo13+1.debian.tar.xz
Files:
 d0649b9d1c09f6317fbf8abea554f5fd 63562 hyprlang_0.6.8.orig.tar.gz
 48503122a56008cd5c4ea0b8f2f13c48 3104 hyprlang_0.6.8-4~bpo13+1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtgob82PcExn/Co6JEWhSvN91FcAFAmoZ5bwACgkQEWhSvN91
FcC+6hAAj1LhzbZRpkwSbzE4em+uunHlwtvU+fDyNN8I34eUD2s0mpX93dN03pgI
1kzQeWi5dtqiin2/R13VpEK99n4BdPBxfParhzpciGL/IUoscG7Y/iV9tkTWdoyq
oWk9r47xwbCUHZDrSnF+GR4jerdLqkojdvGCP5kQDuda6q98yY3KmFUFRE9UPzY5
taUP4xbTvthK3qA8HRPwMXoQIDjYr2pmwaU9pR4MTNtFAr1JDncpLXEVxOB72MvW
wxPrG8OzRQ78kYj7Pw4fd5L3Bw9pga9J6W9kKUh/UKz8k5SY8yZ4vKtnhnQ/DEbL
IntUlCN8gncosiJgkKmgXMK+0vaFY+c/U8om7PaqQj14zjd80PcR1SOA7lBIKceQ
CJaiucndwrB19o/QO67ZEO0nQXOb8DChKxPFhM3OJHbNZMhbXFRuQtLw6UJbJmUF
ST7uW5JGs7qMBUCWrhzsOYoWp1f80D9mesvPK3JDYpVSYYKFyRvdmRMIWFAdmOoC
Oqd23tpUQIftuDsY9e1OgG/HDQMBNDMNkVColkZKg5S1kyzbxRbG3nMVHjeoWz2I
kgMFhd+2COlWsoUzw/sqLIvTbEZpDCouuUdRXfEQ8hgEzHox6jBVhzvdq9QnuD9M
vAPBQ/m2O5q7tp1pubMxMAu3FBXYmaLAp/6+kzrFB1QrE0Ycof4=
=b0Tk
-----END PGP SIGNATURE-----
