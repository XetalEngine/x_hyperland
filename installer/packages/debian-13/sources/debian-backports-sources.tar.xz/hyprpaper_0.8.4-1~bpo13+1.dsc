-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: hyprpaper
Binary: hyprpaper
Architecture: any
Version: 0.8.4-1~bpo13+1
Maintainer: Debian Hyprland Maintainers <team+hyprland@tracker.debian.org>
Uploaders:  Chow Loong Jin <hyperair@debian.org>, Carl Keinath <carl.keinath@gmail.com>, Alan M Varghese (NyxTrail) <alan@digistorm.in>, Alex Myczko <tar@debian.org>,
Homepage: https://github.com/hyprwm/hyprpaper
Standards-Version: 4.7.4
Vcs-Browser: https://salsa.debian.org/hyprland-team/hyprpaper
Vcs-Git: https://salsa.debian.org/hyprland-team/hyprpaper.git
Build-Depends: debhelper-compat (= 13), cmake, hyprwayland-scanner (>= 0.4.2), hyprwire-scanner, libdrm-dev, libgles-dev, libhyprlang-dev (>= 0.6.0), libhyprtoolkit-dev (>= 0.4.1), libhyprutils-dev (>= 0.2.4), libhyprwire-dev, libjpeg-dev, libmagic-dev, libopengl-dev, libpixman-1-dev, libwayland-dev, libwebp-dev, pkgconf, wayland-protocols (>= 1.35)
Package-List:
 hyprpaper deb x11 optional arch=any
Checksums-Sha1:
 92f7f5b3e9acc7b0aed90effacd79216e7fc0525 23340 hyprpaper_0.8.4.orig.tar.gz
 289df4ae739dadf07590ca479f7505a1c987b7a9 5976 hyprpaper_0.8.4-1~bpo13+1.debian.tar.xz
Checksums-Sha256:
 4912c7aede303918f38a3fc6b294429e2d541b639ebba67bcab58d1d367ea360 23340 hyprpaper_0.8.4.orig.tar.gz
 c75b83dd1321ddd82cc82d230beb9f3fa6c466f6e2266af935ca274a472899c6 5976 hyprpaper_0.8.4-1~bpo13+1.debian.tar.xz
Files:
 248068f7592cc21a30fdd44b3da2bf37 23340 hyprpaper_0.8.4.orig.tar.gz
 ab0fb2240c2989ff9225ec799a7a1be0 5976 hyprpaper_0.8.4-1~bpo13+1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtgob82PcExn/Co6JEWhSvN91FcAFAmolyHMACgkQEWhSvN91
FcABkQ//dwP/SlG3RpZa9VyY9MvR91TNaAhQlUxtUqVuUmpLkQ9moIV9uVzjbIPI
2HpxvgZekLAV7igfD2D9SzddNJjB568AYKiQ4y4l0WGGpGNQpOlbPPiMpPDC+Fs0
CRJL4rt4X8I6TvlcL/b8oA4z+WjD0bb5qiT4zd2ZTXxjrvQp4jeok1N8w0om/XSX
IBLw/w09z5XRF0Z+oOYqF2PEdh+aHYRG7QRTF008KJ+EaTFJVsoOk2y+BH+Bb3bM
phHoOaKZ8BRnpOc5hLBmR4vrv8ZbrWfmVfVhVUaY6NulDQsqdsYIM2PTVIfRSaRE
4nRZzMQLTQoN89NSsTjajaXF09tIAS8My52QiNCip5OOsEv2ZSa2ElO2SZJPjh/9
3aB0wFlLbzQNUIE4AYoCYmyMBR/ZZEk6DFH/36jfBV7qwusUDl1SkJLg9l7AcB4F
ILJ9kZnElpC5AbZ8gHHlN+114prGVHAbpgSlIIDpSXw6t6sOip7PAxiu/N6gm3/o
D17Nzz8E2IfPNKbtcyxNSpRum3CkdaBz5j/GqLl/ypB8U/7l7cwY8c3kXGklt4xJ
em0sJvTgigt1O9lQ3jXl5b5HDXFUSR4J88lLjZ8M/g61j6quWLvNDtu5JnWR3fHh
efb2A5ATTqDezSgpk92w+hVjxrkhIYVrTZL6GNUgf1ztJxxNITA=
=gv5L
-----END PGP SIGNATURE-----
