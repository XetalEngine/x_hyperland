-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: hyprwire
Binary: libhyprwire-dev, libhyprwire3, hyprwire-scanner
Architecture: any
Version: 0.3.1-3~bpo13+1
Maintainer: Debian Hyprland Maintainers <team+hyprland@tracker.debian.org>
Uploaders:  Carl Keinath <carl.keinath@gmail.com>, Chow Loong Jin <hyperair@debian.org>, Alex Myczko <tar@debian.org>,
Homepage: https://github.com/hyprwm/hyprwire
Standards-Version: 4.7.4
Vcs-Browser: https://salsa.debian.org/hyprland-team/hyprwire
Vcs-Git: https://salsa.debian.org/hyprland-team/hyprwire.git
Testsuite: autopkgtest
Testsuite-Triggers: @builddeps@
Build-Depends: debhelper-compat (= 13), cmake, libffi-dev, libhyprutils-dev (>= 0.9.0), libpugixml-dev, pkgconf
Package-List:
 hyprwire-scanner deb libs optional arch=any
 libhyprwire-dev deb libdevel optional arch=any
 libhyprwire3 deb libs optional arch=any
Checksums-Sha1:
 0236881a5fde971c846a19d5949e80aa7ccb4cd4 53935 hyprwire_0.3.1.orig.tar.gz
 b3f22709544fe98727c8f7f2848bde16437090c1 7108 hyprwire_0.3.1-3~bpo13+1.debian.tar.xz
Checksums-Sha256:
 47f6032d655aa0567f7d6be2625b1c404bf21c5dbe65f308ad6f3550bc810037 53935 hyprwire_0.3.1.orig.tar.gz
 2f5633d7216c4795a7d4f81c223ff62d83a5485ff6b274ec98c423bea086169b 7108 hyprwire_0.3.1-3~bpo13+1.debian.tar.xz
Files:
 6b4d4770d67100cddd1ca60837e42857 53935 hyprwire_0.3.1.orig.tar.gz
 8273dc692eba61ba35fffe8372ac86e9 7108 hyprwire_0.3.1-3~bpo13+1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtgob82PcExn/Co6JEWhSvN91FcAFAmogMF4ACgkQEWhSvN91
FcDSiQ//UCsy+bZAbBeBKS6Npe9DTtVs6uOP8z70+ywqAc5QDAhdd6k83xG0V3Px
t9JTN5dmXQ9o55nru/PmmA3SeMQss0LY/i+X1xqp+RqlAxtVrRfCZsC5A9+kxhEB
1lD+JD8KERQoroNSXTkTiuOa+sn7Ax/ESJWFXbRHvVyGTYfCMlTk1KkcF4AaoB0X
p0N4u1OhPkO3CeaRfIyQj/w6gIWBQADcYxapt6vbL/F1f1drxZxj0PBbLnHhGEz1
xQcpbvJQ2kOGz8j091c8q9LJWfDGPtaaVfyMQigLjt4hAIBxtlUBuptXN/zpwNl4
yjDfCG65AhoplMtFlfXKmkpUz/3sTwon5wptQ/ziYnR2VbVFBgb0k8dxstX4Ah1A
mFGRt0ukgRLLoEipuXKZLm0atn1d3aVkIrEj6nndoseytM9Wr1gjtPppXxp/5+9w
nXtBwQJN2O0E4vBbf2HywCF6QQIw/gf7boNCPmMSgoZazqyRqpzw6/IA3dwIyQ0+
4GqBqZNBYKRkDe1cgPjNTLBoman6GOyj33NvmGrAKkAdUGCVDKS1/3YWv+M5W+7p
yj5h0P+e++COLb2myou/HKwYBh0n/V6pjF0M3JkXuJ6b5vHG4eftc7uAZ8Rn0Mh5
3hBETdetC29s5E5GPJCrUxeG4iOzvU5v/ZWO/T5kIx2tGWf3Rj4=
=a069
-----END PGP SIGNATURE-----
