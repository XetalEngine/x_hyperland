-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: hyprpolkitagent
Binary: hyprpolkitagent
Architecture: any
Version: 0.1.3-2~bpo13+1
Maintainer: Debian Hyprland Maintainers <team+hyprland@tracker.debian.org>
Uploaders:  Carl Keinath <carl.keinath@gmail.com>, Chow Loong Jin <hyperair@debian.org>,
Homepage: https://github.com/hyprwm/hyprpolkitagent
Standards-Version: 4.7.2
Vcs-Browser: https://salsa.debian.org/hyprland-team/hyprpolkitagent
Vcs-Git: https://salsa.debian.org/hyprland-team/hyprpolkitagent.git
Build-Depends: debhelper-compat (= 13), cmake, libhyprutils-dev, libpolkit-agent-1-dev, libpolkit-qt6-1-dev, pkgconf, qt6-base-dev, qt6-declarative-dev
Package-List:
 hyprpolkitagent deb x11 optional arch=any
Checksums-Sha1:
 4704f9d033a2ca6b0464a89a6335ade7e2aa21d6 32857 hyprpolkitagent_0.1.3.orig.tar.gz
 550cf38908888c271bc7463cee0364f71b641467 2324 hyprpolkitagent_0.1.3-2~bpo13+1.debian.tar.xz
Checksums-Sha256:
 a8fa714b92d47331f056b608cb731dd1f5cc3845a9109cb22c6e6eb55b4eac84 32857 hyprpolkitagent_0.1.3.orig.tar.gz
 f20491dca00fe8f3d5ffac826752faf69e5ad326e37ff6f3545051ab78b4248a 2324 hyprpolkitagent_0.1.3-2~bpo13+1.debian.tar.xz
Files:
 f23402973e3800c3f60b1ea6381b4ad1 32857 hyprpolkitagent_0.1.3.orig.tar.gz
 e26e3a74a942e9fac5be8d4f40455a34 2324 hyprpolkitagent_0.1.3-2~bpo13+1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtgob82PcExn/Co6JEWhSvN91FcAFAmqNpz0ACgkQEWhSvN91
FcCalA//a+Ei8U1J66PWq3wixCxyOOGKky4RPDkIxqspe09WqHXyWLFzygNhya03
Q+aL653KUBYrokumFq/fAarRHS+K3jCdjD/0FCAW5Qpd2OzrGJls4i79cqlyxvvj
n7MxD52MYlhZ8pORUoXHMKb3SGaPdzg1relskzPZ/ZoGDPnh3KcuDDePLNC8Mr9I
H0sdJKejR+A1+24rjm8nEtn+wSZLaNARcQivkUxQZrgAdPCVUX8ynzJhRU/kcbbH
1ZBKNKi2YlpP1uPyrgL8vlSPG27g7Jjwdp9VF+NvIRz15ep5NlCRj2dGU8yMSjjX
eq5gPDwuTatNGBnTp2xVsOMejvk5qfiZxkY0COok4D3UtZJ6+4IDUsbkSCrZLNwJ
cRgHhHi210rqOcwvF7qGm05+djsLGFyYYC0cZhBQADuOvKppoPwEFTXrce0t7m2F
orrPfdyXi71UYo4kHeuAoY29nf9v5+UPnRJadyMofqZgBRVhGNdHEnNhqxWCyPxU
R6aEt24y1McuI9QgA3LzcvTUxv51+tiSAR0VXSDPrXzplp+JDm8z5ozfQgQEFajH
ZWjgjwd+iKAUqBi7fQZ9UAn/KSW29rFmOpyRUo0+CO48B+bQdx6Bn8p8GLZl4Xoq
PIuHPXsPicvIwjHfIVVXOHax5pW5MJtoceqWXrIllkhj7ZrS3AI=
=pNaR
-----END PGP SIGNATURE-----
