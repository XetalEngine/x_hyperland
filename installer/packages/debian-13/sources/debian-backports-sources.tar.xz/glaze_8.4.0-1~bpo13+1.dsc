-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: glaze
Binary: libglaze-dev, libglaze-doc
Architecture: all
Version: 8.4.0-1~bpo13+1
Maintainer: Carl Keinath <carl.keinath@gmail.com>
Uploaders:  Alex Myczko <tar@debian.org>, Chow Loong Jin <hyperair@debian.org>,
Homepage: https://github.com/stephenberry/glaze/tree/main
Description: High-performance C++ JSON serialization library
 Glaze is a high-performance C++ library for JSON and other structured formats,
 it provides efficient serialization and deserialization.
Standards-Version: 4.7.4
Vcs-Browser: https://salsa.debian.org/carlo/glaze
Vcs-Git: https://salsa.debian.org/carlo/glaze.git
Testsuite: autopkgtest
Testsuite-Triggers: cmake, g++, libasio-dev, libeigen3-dev, libopenalgz-ut-dev, libsqlite3-dev, libssl-dev
Build-Depends: debhelper-compat (= 13), cmake, mkdocs <!nodoc>, mkdocs-autorefs <!nodoc>, mkdocs-material <!nodoc>
Package-List:
 libglaze-dev deb libdevel optional arch=all
 libglaze-doc deb doc optional arch=all profile=!nodoc
Checksums-Sha1:
 511585d3ae6c4f28d12cd41954d60b2322daaff6 2189568 glaze_8.4.0.orig.tar.gz
 70c9b6e94c3142b966d4b6d4f7f3b56654447458 7628 glaze_8.4.0-1~bpo13+1.debian.tar.xz
Checksums-Sha256:
 11798c66c54adf169aa4b4d3da7eb8280755289bb2bbc39664a595a4da60caaf 2189568 glaze_8.4.0.orig.tar.gz
 bcc262771f5256f5a3407c748f656be8a2c7cb9bacfc7cf211bbff10060d5fa7 7628 glaze_8.4.0-1~bpo13+1.debian.tar.xz
Files:
 6d4247e30aa057ddd007d8654a4a9358 2189568 glaze_8.4.0.orig.tar.gz
 87896703db0d13c5385e89678b238d9c 7628 glaze_8.4.0-1~bpo13+1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtgob82PcExn/Co6JEWhSvN91FcAFAmq8JYAACgkQEWhSvN91
FcC5JA//XhDoe1q4WF2d1CfogCxi0dmLtna2DYI0CHa9KOCKE/dKBDdpoWH0Xn13
ao3MZhrpPv0z67MlxaNIBhsrl+ocYvmpS2dmLJqDJdy/xYLQ/X9nJYSQ+lm/CbaK
UhZgGsCegtJX6dD5UdZJamfav6f+Dy0qkLGYeI44hi2q0ZskHJaw6tlaPOrc6T7u
STcy9KCKzh32pr4O4WvlqhTZ3M4tKHzr8C8A4jwCjgm2qJ2KYjyAmcHl1klnsoU/
d2L0y9sx/cUL3QEM9MzOcQte0mUSMealNzP3oA5Es7gS0r3Kid3HjNomNsaDuWbM
/YuOfPHwi4cbF2hB/cDZpx8BBVS4/uUS68dkJaOym+U1HDYpuc4Kae1uidQnKTIM
+vJXxCn9aHogBpHBXi448sta0JufQKpFxlXF239/N5jsuqwQG9XNPN2H/ouM9Ss0
+t3h3jla+h34763BFj4r3yaU2Ezl5f8lGr+p2VfeTYLfsfTlZ8K2IFMoftVGVcri
EObNRmarT4ebdvZwes4tmlBUqSxkZQFqMC8q252qFBqKMbWDmvJSNUyg0yOSFRPH
3Xmxz/tcIIccIAnLpEsrLPUXpq6rtBXalOrLmaKD1oGiP3AU5fFDVQUsQ3I27GTL
NQkENifAWteXA27McBfSU+rAmVCT1lM7gr4H+UcaA5JmuOg7fpI=
=ef2X
-----END PGP SIGNATURE-----
