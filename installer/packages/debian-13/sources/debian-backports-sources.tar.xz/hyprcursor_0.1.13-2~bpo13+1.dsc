-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: hyprcursor
Binary: hyprcursor-util, libhyprcursor0, libhyprcursor-dev
Architecture: any
Version: 0.1.13-2~bpo13+1
Maintainer: Debian Hyprland Maintainers <team+hyprland@tracker.debian.org>
Uploaders:  Alan M Varghese (NyxTrail) <alan@digistorm.in>, Carl Keinath <carl.keinath@gmail.com>, Chow Loong Jin <hyperair@debian.org>, Alex Myczko <tar@debian.org>,
Homepage: https://github.com/hyprwm/hyprcursor
Standards-Version: 4.7.4
Vcs-Browser: https://salsa.debian.org/hyprland-team/hyprcursor
Vcs-Git: https://salsa.debian.org/hyprland-team/hyprcursor.git
Testsuite: autopkgtest
Testsuite-Triggers: cmake, g++, libcairo2-dev, pkgconf
Build-Depends: cmake, debhelper-compat (= 13), libcairo2-dev, libhyprlang-dev (>= 0.4.2), librsvg2-dev, libtomlplusplus-dev, libzip-dev, pkgconf
Package-List:
 hyprcursor-util deb x11 optional arch=any
 libhyprcursor-dev deb libdevel optional arch=any
 libhyprcursor0 deb libs optional arch=any
Checksums-Sha1:
 9faa299842c73248ba62a9b0acb299fa6419b0e5 28690 hyprcursor_0.1.13.orig.tar.gz
 ba0fa7947343e65b919074c669db5f085be4950f 6456 hyprcursor_0.1.13-2~bpo13+1.debian.tar.xz
Checksums-Sha256:
 2732743915131415d462ca2d36420f03a1f7a575ce874878b9f64fb8616bf55b 28690 hyprcursor_0.1.13.orig.tar.gz
 7570b867a33b7934820b38ba2a755d8ec4f748d2b370d2bdbca4ae0d0379e1c5 6456 hyprcursor_0.1.13-2~bpo13+1.debian.tar.xz
Files:
 92b184da22fd846ba60f9fe1b635c9f0 28690 hyprcursor_0.1.13.orig.tar.gz
 d1e05683f79373cacc73c7ad6de45b1a 6456 hyprcursor_0.1.13-2~bpo13+1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtgob82PcExn/Co6JEWhSvN91FcAFAmoZ5Y0ACgkQEWhSvN91
FcD4kQ//cRMhWflReXfg8B3ag4uamv5+da5Gh6vkVlPGl0dKZ014ADRfsASnPMu0
HtgnAkos+SlPhk+mq3DhR4EWBxLwYUqdK6jvV4x4l+S8AZhmw2oUIvRPdsCxIT4G
r5TrjFOBMMyoRmaNXqyWT4yuPv4j75Gk0aP7QiCb2pvcRlEx14Yq6TOVcrQzIZSU
8HTfFZBLIBIQkFZpVrNGvvtyqvQbh9AybC6A0sJKmH6+yCSEC4Ej0VnMem/K/mDo
k91xp55TKUD76/qLbhVqrsqhqCLma00xBlz2doIpCrbQ4d8T+/7bQtiKJ6HRfJsC
4DhZyy+vlCA03BU3O/THRS/kp1FYqJgtk5LeOjTgPp5aMkRT9KzxaOcFl2m0J6Yj
EaMZPHINw3O70wHijnGIhGw4pXBhi6cRqNkW1kOtr1t08/A7hZkYJjcjs+UcnPmm
tTDbx4HXROrBzSXRZLibAFDTFx88+VaaX8cY9yF4LsEfpGrazWXUUyrujvJPzEqd
kgMjFOzyczVlWsdzyG47XBsomN0SQN3hJCb2qtCRhJDlsMSXXS9TzniU0bL8IVEK
6xSctpWRgQLSS7dCDApPDrOQT9B4FibQwsd2RgwhhzTcZ2JPN4l0qzVXTDZ2xQ/L
AGXOnTO5skhHHRGy7tUAN4oEqVNo7MCLyylzk6r7c+ebMZXels8=
=S02W
-----END PGP SIGNATURE-----
