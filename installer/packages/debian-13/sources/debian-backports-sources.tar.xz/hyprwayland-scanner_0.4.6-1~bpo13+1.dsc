-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: hyprwayland-scanner
Binary: hyprwayland-scanner
Architecture: any
Version: 0.4.6-1~bpo13+1
Maintainer: Debian Hyprland Maintainers <team+hyprland@tracker.debian.org>
Uploaders:  Alan M Varghese (NyxTrail) <alan@digistorm.in>, Carl Keinath <carl.keinath@gmail.com>, Chow Loong Jin <hyperair@debian.org>, Alex Myczko <tar@debian.org>,
Homepage: https://github.com/hyprwm/hyprwayland-scanner
Standards-Version: 4.7.4
Vcs-Browser: https://salsa.debian.org/hyprland-team/hyprwayland-scanner
Vcs-Git: https://salsa.debian.org/hyprland-team/hyprwayland-scanner.git
Testsuite: autopkgtest
Testsuite-Triggers: g++, libwayland-dev, pkgconf
Build-Depends: debhelper-compat (= 13), cmake, libpugixml-dev, pkgconf
Package-List:
 hyprwayland-scanner deb libdevel optional arch=any
Checksums-Sha1:
 657795e4fb90b9f7758da934b17d013255c31c4f 11515 hyprwayland-scanner_0.4.6.orig.tar.gz
 436a4f06ad9defb68a2bf79516349cf6dce76e65 4032 hyprwayland-scanner_0.4.6-1~bpo13+1.debian.tar.xz
Checksums-Sha256:
 f4f574c9339ddf85cd97d423b335bfff81458ed6dd03407e556346089bab3e4a 11515 hyprwayland-scanner_0.4.6.orig.tar.gz
 80dbc50bd8e10e676a3f686ce7a929873afe23ba8e69604be248cd6a2b7a4b7b 4032 hyprwayland-scanner_0.4.6-1~bpo13+1.debian.tar.xz
Files:
 b9765ff82e7111344aed2dd7117511b8 11515 hyprwayland-scanner_0.4.6.orig.tar.gz
 31a06c1baf0f2c7ce7e437db345214a0 4032 hyprwayland-scanner_0.4.6-1~bpo13+1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtgob82PcExn/Co6JEWhSvN91FcAFAmoZ3mwACgkQEWhSvN91
FcDhAg//V1OcJYA2HMvBbDBrdcIL4AqXqHwraDuqJFn5ZhOBdSQimJpc7DNvVu7X
aQ1RQl/yg9q96mV1l6XHD9xkjr3t25IiEbVKoeUnElt0waSTQsTfh1IjBZPjh3St
mYtEq3EwkscG3f4YxR0fW/Zx2DLmzzEowkBAlQdBzl8EXMnAYYHGkvxXFfyxVS48
j75suj3sZURZOEHgJXnYdJ9QPW1jIcc5y+YfjX97k0dc4iWvDpAsD3qw7WkgU5wX
gOGzz576/EU6T6C12xGUj8J0PqStepazEcbdIEcTH7JNu/R09x73+LupNq54KoeT
9MsZQPn5GA5UHaKab9+Vi4yTqQk0VpXDSH+8hdc8u0AfVziuHxedfhr8zW7/YrUq
JA+hwGGXzpAMRs+tsh22TifYDBjfcrEvo911a7ahDlHsBMna/f7AkMV7/PmHXGpa
DTdRbffT4Bh4xNmvakJkqw/mjW5dUiCzs7qzbyHDg9bHYSXfXaDfyV4MolRkMYb+
IqCf0PVpd64aYgBkViMJNhCVrXUlDES8OzIR1w01fY/GCRkyIpmQcUh8vLH2cGeY
21Zst4rzIgXWzB0mwXAlm8nkGSSNYVeiXb7Cf55UatPO/VH70JZWIwA3cw8o8Daw
odNfoHMMJNJPXecWWZ22VHbWkhDhFCe0siP+z9OV/hl+5VtIMcE=
=UcDG
-----END PGP SIGNATURE-----
