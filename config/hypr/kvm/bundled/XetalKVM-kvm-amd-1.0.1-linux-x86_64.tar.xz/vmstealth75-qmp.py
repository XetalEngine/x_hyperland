#!/usr/bin/env python3
"""Read a named KVM guest's state through vmstart_2's QMP socket."""

import json
import socket
import sys
import time


def guest_state(path, expected_name):
    # vmstart_2's shutdown watcher also uses this socket. Allow its connection
    # to finish, but never leave the Windows SSH command waiting indefinitely.
    deadline = time.monotonic() + 10
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
        client.settimeout(10)
        try:
            client.connect(path)
        except FileNotFoundError:
            return "shut off"

        with client.makefile("rb") as stream:
            def receive():
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError("QMP did not respond within 10 seconds")
                client.settimeout(remaining)
                line = stream.readline(65537)
                if not line or len(line) > 65536 or not line.endswith(b"\n"):
                    raise ValueError("QMP closed or returned an incomplete/oversized reply")
                message = json.loads(line)
                if not isinstance(message, dict):
                    raise ValueError("invalid QMP reply")
                return message

            if "QMP" not in receive():
                raise ValueError("socket did not provide a QMP greeting")

            def query(command):
                request_id = "vmstealth75-" + command
                client.sendall(json.dumps({"execute": command, "id": request_id}).encode() + b"\n")
                while True:
                    reply = receive()
                    if "event" in reply:
                        continue
                    if "error" in reply:
                        raise ValueError(f"QMP {command} failed: {reply['error']}")
                    if reply.get("id") != request_id:
                        continue
                    result = reply.get("return")
                    if not isinstance(result, dict):
                        raise ValueError(f"invalid QMP {command} result")
                    return result

            query("qmp_capabilities")
            name = query("query-name").get("name")
            if name != expected_name:
                raise ValueError(f"QMP guest is {name!r}, expected {expected_name!r}")
            if query("query-kvm").get("enabled") is not True:
                raise ValueError("the guest is not using KVM acceleration")
            status = query("query-status")
            state = status.get("status")
            if not isinstance(state, str) or not state:
                raise ValueError("QMP did not return a guest state")
            if state == "running" and status.get("running") is not True:
                raise ValueError("QMP did not confirm the guest CPUs are running")
            return state


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit("Usage: vmstealth75-qmp.py SOCKET GUEST_NAME")
    try:
        print(guest_state(sys.argv[1], sys.argv[2]))
    except (OSError, ValueError) as error:
        sys.exit(f"vmstealth75: cannot read QMP guest state: {error}")
