@echo off
setlocal
REM Run once after Windows has reached the desktop.
REM The patched 7.2.11 KVM modules must already be loaded on the Linux host.
ssh -o ConnectTimeout=15 xetal@192.168.1.130 "/home/xetal/a_xetal_engine/a/CachyOsTools/staging/port-7.2.11/vmstealth75.sh --qmp /tmp/qmp-win10.sock"
set "Result=%errorlevel%"
if not "%Result%"=="0" (
    echo.
    echo vmstealth75 failed. Read the message above before retrying.
)
pause
exit /b %Result%
