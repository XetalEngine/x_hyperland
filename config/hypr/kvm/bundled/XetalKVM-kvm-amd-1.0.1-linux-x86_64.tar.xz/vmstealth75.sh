#!/usr/bin/env bash
# Run from Windows over SSH after the guest has reached the desktop.
set -euo pipefail

readonly ScriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly TargetRelease="7.2.11-arch1-1"
readonly ModuleDir="$ScriptDir/src/linux/src/linux-7.2.11/arch/x86/kvm"
readonly SysModuleDir=/sys/module
readonly Param="$SysModuleDir/kvm_amd/parameters/intercept_cpuid"

Domain=win10
QmpSocket=/tmp/qmp-win10.sock
Action=off
ActionSet=false

Die() { printf 'vmstealth75: %s\n' "$*" >&2; exit 1; }

Usage() {
    printf 'Usage: %s [--status | --cpuid on|off] [--domain NAME] [--qmp PATH | --libvirt]\n' "$0"
    printf '%s\n' \
        'Default: turn CPUID interception off after Windows reaches the desktop.' \
        'The normal host-reboot/VM-launch cycle loads the modules with CPUID interception on.' \
        'Use --cpuid on before restarting Windows without restarting the host.' \
        'Requires the patched modules for 7.2.11-arch1-1 to be loaded already.' \
        'Default: check vmstart_2 through /tmp/qmp-win10.sock.' \
        'Use --libvirt only for a guest started through the older libvirt launcher.' \
        'The parameter affects all AMD KVM guests on this host.' \
        '--domain selects the guest whose running state is checked (default: win10).'
}

SelectAction() {
    [[ "$ActionSet" == false ]] || Die 'choose one action: --status or --cpuid on|off'
    Action="$1"
    ActionSet=true
}

while (($#)); do
    case "$1" in
        --status) SelectAction status ;;
        --cpuid)
            (($# >= 2)) || Die '--cpuid needs on or off'
            [[ "$2" == on || "$2" == off ]] || Die '--cpuid needs on or off'
            SelectAction "$2"
            shift
            ;;
        --domain)
            (($# >= 2)) && [[ -n "$2" && "$2" != --* ]] || Die '--domain needs a name'
            Domain="$2"
            shift
            ;;
        --qmp)
            (($# >= 2)) && [[ "$2" == /* ]] || Die '--qmp needs an absolute socket path'
            QmpSocket="$2"
            shift
            ;;
        --libvirt) QmpSocket= ;;
        -h|--help) Usage; exit 0 ;;
        *) Die "unknown option: $1 (try --help)" ;;
    esac
    shift
done

DomainState() {
    if [[ -n "$QmpSocket" ]]; then
        sudo -n python3 "$ScriptDir/vmstealth75-qmp.py" "$QmpSocket" "$Domain"
    else
        LC_ALL=C sudo -n virsh -c qemu:///system domstate --domain "$Domain"
    fi
}

ReadValue() {
    if [[ -r "$1" ]]; then
        cat "$1"
    else
        printf 'unavailable\n'
    fi
}

RequirePatchedModules() {
    local RunningRelease Entry Module File Expected Loaded
    RunningRelease="$(uname -r)"
    [[ "$RunningRelease" == "$TargetRelease" ]] ||
        Die "requires $TargetRelease; running kernel is $RunningRelease"
    [[ -e "$Param" ]] ||
        Die "patched kvm_amd is not loaded; with all VMs stopped, run $ScriptDir/build-kvm.sh on the host"

    for Entry in kvm:kvm.ko kvm_amd:kvm-amd.ko; do
        Module="${Entry%%:*}"
        File="${Entry#*:}"
        [[ -f "$ModuleDir/$File" && -r "$SysModuleDir/$Module/srcversion" ]] ||
            Die "cannot verify $Module against $ModuleDir/$File"
        Expected="$(modinfo -F srcversion "$ModuleDir/$File")" ||
            Die "cannot read the built $File"
        Loaded="$(<"$SysModuleDir/$Module/srcversion")"
        [[ -n "$Expected" && "$Loaded" == "$Expected" ]] ||
            Die "$Module does not match this port; with all VMs stopped, load $ScriptDir/build-kvm.sh first"
    done
}

SetCpuid() {
    local Want="$1" Value Expected State
    RequirePatchedModules

    if [[ "$Want" == off ]]; then
        State="$(DomainState)" || Die "cannot verify $Domain is running; CPUID was not changed"
        [[ "$State" == running ]] ||
            Die "$Domain is $State; boot Windows to the desktop before running this launcher"
        Value=0
        Expected=N
    else
        Value=1
        Expected=Y
    fi

    if [[ "$(<"$Param")" != "$Expected" ]]; then
        printf '%s\n' "$Value" | sudo -n tee "$Param" >/dev/null ||
            Die 'could not set CPUID interception; the SSH user needs passwordless sudo for this operation'
    fi
    [[ "$(<"$Param")" == "$Expected" ]] || Die 'CPUID setting did not read back as requested'

    if [[ "$Want" == off ]]; then
        printf 'vmstealth75: CPUID interception is OFF; guest CPUID executes directly.\n'
    else
        printf 'vmstealth75: CPUID interception is ON; ready for the next guest boot.\n'
    fi
}

Status() {
    local State
    State="$(DomainState 2>/dev/null)" || State=unavailable
    printf 'kernel: %s\n' "$(uname -r)"
    printf 'guest: %s (%s)\n' "$Domain" "$State"
    printf 'guest status source: %s\n' "${QmpSocket:-libvirt}"
    printf 'CPUID interception: %s (Y = intercepted, N = native)\n' "$(ReadValue "$Param")"
    printf 'VMMCALL interception: %s\n' "$(ReadValue "$SysModuleDir/kvm_amd/parameters/intercept_vmmcall")"
    printf 'burst CPU-buffer clearing: %s\n' "$(ReadValue "$SysModuleDir/kvm_amd/parameters/cpuid_leaf_0_burst_clear_buffers")"
    printf 'scope: all AMD KVM guests on this host\n'
}

[[ "$Action" == status ]] || SetCpuid "$Action"
Status
