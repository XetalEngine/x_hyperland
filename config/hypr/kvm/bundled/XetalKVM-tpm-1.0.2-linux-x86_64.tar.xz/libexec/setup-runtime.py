#!/usr/bin/env python3
"""Resolve bundled TPM helpers and keep each user's certificate authority private."""
from pathlib import Path
import fcntl
import os
import pwd
import subprocess
import sys

root=Path(__file__).resolve().parent.parent
args=sys.argv[1:]
env=dict(os.environ,PATH=str(root/'bin')+os.pathsep+os.environ.get('PATH','/usr/bin:/bin'))
loader=next((root/'lib').glob('ld-linux-*'))
command=[str(loader),'--library-path',str(root/'lib'),str(root/'libexec/swtpm_setup')]
if any(a in ('--help','--version','--print-capabilities','--config') or a.startswith('--config=') for a in args):
    os.execve(str(loader),command+args,env)
owner=pwd.getpwuid(int(os.environ.get('SUDO_UID',os.getuid())) if os.geteuid()==0 else os.getuid())
data=Path(os.environ.get('XETAL_KVM_DATA',str(Path(owner.pw_dir)/'.local/share/xetal-kvm')))
ca=data/'tpm-localca'
ca.mkdir(parents=True,exist_ok=True,mode=0o700)
os.umask(0o077)
with (ca/'.setup.lock').open('a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    localca=ca/'localca.conf';options=ca/'localca.options';config=ca/'setup.conf'
    localca.write_text(''.join(f'{key} = {ca/path}\n' for key,path in (
        ('statedir','.'),('signingkey','signkey.pem'),('issuercert','issuercert.pem'),('certserial','certserial'))))
    if not options.exists():
        options.write_text('--platform-manufacturer Xetal\n--platform-version 1.0\n--platform-model Virtual-Machine\n')
    config.write_text(f'create_certs_tool = {root}/bin/swtpm_localca\ncreate_certs_tool_config = {localca}\ncreate_certs_tool_options = {options}\n')
    if '--tpm' not in args:args=['--tpm',str(root/'bin/swtpm')+' socket',*args]
    try:result=subprocess.call(command+['--config',str(config),*args],env=env)
    finally:
        if os.geteuid()==0:
            for path in [ca,*ca.rglob('*')]:
                if not path.is_symlink():os.chown(path,owner.pw_uid,owner.pw_gid)
    raise SystemExit(result)
