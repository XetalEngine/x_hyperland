#!/usr/bin/env bash
# Dump TPM 2.0 fixed properties for gen-tpm-vendor-identity-h.sh (labels match tpm2-tools output).
# Uses: tpm2 getcap properties-fixed (package tpm2-tools).
# Writes KEY=value lines to stdout; prefix # lines are comments.
#
# Device order: TPM2TOOLS_DEVICE, /dev/tpmrm0, /dev/tpm0
# Reads without sudo if permitted; otherwise tries sudo.

set -euo pipefail

pick_hex() {
	# Take the "raw:" line belonging to exactly this property.
	#
	# Must not use `grep -F label -A3`: tpm2-tools prints some values without an
	# 0x prefix (TPM2_PT_LEVEL is "raw: 0"), so a pattern anchored on 0x skips
	# the real line and silently picks up the NEXT property's value -- which
	# made LEVEL come out as REVISION's 0x9F. Anchor on the label, stop at the
	# next property, and accept bare decimals too (gen-... normalises them).
	local label="$1"
	awk -v lbl="${label}:" '
		$1 == lbl        { found = 1; next }
		found && $1 == "raw:" { print $2; exit }
		found && /^[^[:space:]]/ { exit }
	' "${RAWFILE}" || true
}

pick_val_dec() {
	# Optional second line "value: 1.59" etc. — not used for codegen; hex raw is authoritative.
	true
}

have_tpm2() {
	command -v tpm2 >/dev/null 2>&1
}

RAWFILE=""
cleanup() { [[ -n "${RAWFILE}" ]] && rm -f "${RAWFILE}"; }
trap cleanup EXIT

run_getcap() {
	local dev="$1"
	TPM2TOOLS_DEVICE="$dev" tpm2 getcap properties-fixed 2>/dev/null
}

RAWFILE=$(mktemp)

DEV="${TPM2TOOLS_DEVICE:-}"
if [[ -z "${DEV}" ]]; then
	for d in /dev/tpmrm0 /dev/tpm0; do
		if [[ -r "$d" ]]; then DEV="$d"; break; fi
	done
fi
if [[ -z "${DEV}" ]]; then
	for d in /dev/tpmrm0 /dev/tpm0; do
		if [[ -c "$d" ]]; then DEV="$d"; break; fi
	done
fi

if [[ -z "${DEV}" ]]; then
	echo "error: no /dev/tpmrm0 or /dev/tpm0 (enable TPM in firmware)" >&2
	exit 1
fi

if ! have_tpm2; then
	echo "error: tpm2 not found — install tpm2-tools (pacman -S tpm2-tools)" >&2
	exit 1
fi

fill_raw() {
	run_getcap "$1" >"${RAWFILE}" || return 1
	if ! grep -q MANUFACTURER "${RAWFILE}" 2>/dev/null; then
		return 1
	fi
	return 0
}

if ! fill_raw "${DEV}"; then
	if sudo -n true 2>/dev/null || sudo -v; then
		DEV_TRY="${DEV}"
		sudo env TPM2TOOLS_DEVICE="${DEV_TRY}" tpm2 getcap properties-fixed >"${RAWFILE}" || {
			for d in /dev/tpmrm0 /dev/tpm0; do
				[[ -c "$d" ]] || continue
				sudo env TPM2TOOLS_DEVICE="$d" tpm2 getcap properties-fixed >"${RAWFILE}" && DEV="$d" && break
			done || true
		}
	fi
fi

if ! grep -qE 'MANUFACTURER|TPM2_PT_MANUFACTURER' "${RAWFILE}" 2>/dev/null; then
	echo "error: tpm2 getcap properties-fixed produced no TPM2 fixed props (wrong TCTI or permissions)" >&2
	echo "Try: sudo env TPM2TOOLS_DEVICE=/dev/tpmrm0 tpm2 getcap properties-fixed | head" >&2
	exit 1
fi

echo "# TPM_REAL_DUMP DEVICE=${DEV} DATE=$(date -Is 2>/dev/null || date)"
echo "TPM2_PT_MANUFACTURER=$(pick_hex TPM2_PT_MANUFACTURER)"
echo "TPM2_PT_FIRMWARE_VERSION_1=$(pick_hex TPM2_PT_FIRMWARE_VERSION_1)"
echo "TPM2_PT_FIRMWARE_VERSION_2=$(pick_hex TPM2_PT_FIRMWARE_VERSION_2)"
echo "TPM2_PT_VENDOR_STRING_1=$(pick_hex TPM2_PT_VENDOR_STRING_1)"
echo "TPM2_PT_VENDOR_STRING_2=$(pick_hex TPM2_PT_VENDOR_STRING_2)"
echo "TPM2_PT_VENDOR_STRING_3=$(pick_hex TPM2_PT_VENDOR_STRING_3)"
echo "TPM2_PT_VENDOR_STRING_4=$(pick_hex TPM2_PT_VENDOR_STRING_4)"
echo "TPM2_PT_VENDOR_TPM_TYPE=$(pick_hex TPM2_PT_VENDOR_TPM_TYPE)"
echo "TPM2_PT_LEVEL=$(pick_hex TPM2_PT_LEVEL)"
echo "TPM2_PT_REVISION=$(pick_hex TPM2_PT_REVISION)"
echo "TPM2_PT_YEAR=$(pick_hex TPM2_PT_YEAR)"
echo "TPM2_PT_DAY_OF_YEAR=$(pick_hex TPM2_PT_DAY_OF_YEAR)"
echo "TPM2_PT_PS_FAMILY_INDICATOR=$(pick_hex TPM2_PT_PS_FAMILY_INDICATOR)"
echo "TPM2_PT_PS_LEVEL=$(pick_hex TPM2_PT_PS_LEVEL)"
echo "TPM2_PT_PS_REVISION=$(pick_hex TPM2_PT_PS_REVISION)"
echo "TPM2_PT_PS_YEAR=$(pick_hex TPM2_PT_PS_YEAR)"
echo "TPM2_PT_PS_DAY_OF_YEAR=$(pick_hex TPM2_PT_PS_DAY_OF_YEAR)"
