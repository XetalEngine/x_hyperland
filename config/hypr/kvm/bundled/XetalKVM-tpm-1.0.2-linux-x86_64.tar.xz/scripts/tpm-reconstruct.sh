#!/usr/bin/env bash
#
# Interactive vTPM reconstruction for a libvirt domain.
#
# Launched by the "TPM Chip Reconstruction" button in vmstart.py, and by the
# reset_tpm shell function. Walks through every option instead of silently
# nuking the vTPM the way the old reset_tpm did.
#
#   ./tpm-reconstruct.sh [domain]      # default domain: win10
#
# The spoofed AMD fTPM identity is compiled into libtpms, so anything this
# script manufactures with $PREFIX/bin/swtpm is spoofed automatically -- there
# is no extra step. Rebuilding that identity is xetaltpm.sh's job, not this
# script's.

set -uo pipefail

# Re-exec as root. Deliberately NOT `sudo -E`: swtpm_setup resolves its config
# via $XDG_CONFIG_HOME/$HOME before sysconfdir, and inheriting the desktop
# user's values would silently pick the wrong swtpm_setup.conf.
if [[ ${EUID} -ne 0 ]]; then
	exec sudo \
		${PREFIX:+PREFIX="$PREFIX"} \
		${SWTPM_STATE_ROOT:+SWTPM_STATE_ROOT="$SWTPM_STATE_ROOT"} \
		bash "$0" "$@"
fi

readonly ScriptDir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
readonly TpmRoot="$(cd -- "$ScriptDir/.." && pwd)"
readonly Prefix="${PREFIX:-$TpmRoot/_install}"
readonly Swtpm="$Prefix/bin/swtpm"
readonly SwtpmSetup="$Prefix/bin/swtpm_setup"
readonly Domain="${1:-win10}"

# Physical-TPM adoption pipeline: dump a real chip -> regenerate the vendor
# identity header -> rebuild libtpms/swtpm so the vTPM impersonates that chip.
readonly DumpScript="$ScriptDir/dump-real-tpm.sh"
readonly GenScript="$ScriptDir/gen-tpm-vendor-identity-h.sh"
readonly XetalTpm="$TpmRoot/xetaltpm.sh"
readonly DumpEnv="$TpmRoot/tpm_real_dump.env"
readonly IdentityHeader="$TpmRoot/libtpms/src/tpm_vendor_identity.h"

# Separate script on purpose: that one rewrites the endorsement key of the
# REAL chip on the board, which is a completely different blast radius from
# anything under /var/lib/libvirt/swtpm.
readonly HwidScript="$ScriptDir/tpm-hwid-reprovision.sh"

readonly C_RESET=$'\e[0m' C_BOLD=$'\e[1m' C_DIM=$'\e[2m'
readonly C_RED=$'\e[31m' C_GREEN=$'\e[32m' C_YELLOW=$'\e[33m' C_BLUE=$'\e[36m'

info() { printf '%s[*]%s %s\n' "$C_BLUE" "$C_RESET" "$*"; }
good() { printf '%s[+]%s %s\n' "$C_GREEN" "$C_RESET" "$*"; }
warn() { printf '%s[!]%s %s\n' "$C_YELLOW" "$C_RESET" "$*"; }
fail() { printf '%s[x]%s %s\n' "$C_RED" "$C_RESET" "$*" >&2; }

pause_exit() {
	local code=${1:-0}
	echo
	read -r -p "Press Enter to close... " _ || true
	exit "$code"
}

die() {
	fail "$*"
	pause_exit 1
}

rule() { printf '%s%s%s\n' "$C_DIM" "------------------------------------------------------------" "$C_RESET"; }

# ---------------------------------------------------------------- prompts ---

# ask_choice <varname> <prompt> <default-index> <option>...
ask_choice() {
	local __var=$1 prompt=$2 default=$3
	shift 3
	local options=("$@") i choice
	echo
	printf '%s%s%s\n' "$C_BOLD" "$prompt" "$C_RESET"
	for i in "${!options[@]}"; do
		if ((i + 1 == default)); then
			printf '  %d) %s %s(default)%s\n' "$((i + 1))" "${options[i]}" "$C_DIM" "$C_RESET"
		else
			printf '  %d) %s\n' "$((i + 1))" "${options[i]}"
		fi
	done
	while true; do
		read -r -p "  > [$default] " choice
		choice=${choice:-$default}
		if [[ $choice =~ ^[0-9]+$ ]] && ((choice >= 1 && choice <= ${#options[@]})); then
			printf -v "$__var" '%s' "${options[choice - 1]}"
			return 0
		fi
		fail "Enter a number between 1 and ${#options[@]}."
	done
}

# ask_yn <varname> <prompt> <Y|N default>
ask_yn() {
	local __var=$1 prompt=$2 default=$3 reply hint
	[[ $default == Y ]] && hint="[Y/n]" || hint="[y/N]"
	while true; do
		read -r -p "$(printf '%s%s%s %s ' "$C_BOLD" "$prompt" "$C_RESET" "$hint")" reply
		reply=${reply:-$default}
		case ${reply,,} in
		y | yes)
			printf -v "$__var" '%s' yes
			return 0
			;;
		n | no)
			printf -v "$__var" '%s' no
			return 0
			;;
		esac
		fail "Answer y or n."
	done
}

# ------------------------------------------------------------ environment ---

[[ -x $SwtpmSetup ]] || die "missing $SwtpmSetup -- run xetaltpm.sh --no-tpm-dump first."
[[ -x $Swtpm ]] || die "missing $Swtpm -- run xetaltpm.sh --no-tpm-dump first."
command -v virsh >/dev/null || die "virsh not found."

Uuid=$(virsh --connect qemu:///system domuuid "$Domain" 2>/dev/null | tr -d '[:space:]')
[[ -n $Uuid ]] || die "domain '$Domain' not found in qemu:///system."

# SWTPM_STATE_ROOT exists so this can be pointed at scratch storage for a dry
# run; leave it unset to operate on the real per-domain state libvirt uses.
readonly SwtpmRoot="${SWTPM_STATE_ROOT:-/var/lib/libvirt/swtpm}/$Uuid"

# libvirt runs swtpm as swtpm_user (tss by default) and qemu.conf here sets
# dynamic_ownership=0, so nothing will fix ownership for us afterwards. Mirror
# whatever the existing state uses; fall back to tss when starting from nothing.
detect_owner() {
	local d=$1
	if [[ -d $d ]]; then
		stat -c '%U:%G' "$d"
	elif id tss >/dev/null 2>&1; then
		echo "tss:tss"
	else
		echo "root:root"
	fi
}

state_dir_for() { [[ $1 == 2.0 ]] && echo "$SwtpmRoot/tpm2" || echo "$SwtpmRoot/tpm1.2"; }
state_file_for() { [[ $1 == 2.0 ]] && echo "$(state_dir_for "$1")/tpm2-00.permall" || echo "$(state_dir_for "$1")/tpm-00.permall"; }

# --------------------------------------------------------------- reporting ---

show_current() {
	local ver=$1 dir file
	dir=$(state_dir_for "$ver")
	file=$(state_file_for "$ver")
	rule
	printf '%sCurrent TPM %s state%s\n' "$C_BOLD" "$ver" "$C_RESET"
	if [[ -f $file ]]; then
		printf '  file     : %s\n' "$file"
		printf '  size     : %s bytes\n' "$(stat -c '%s' "$file")"
		printf '  modified : %s\n' "$(stat -c '%y' "$file" | cut -d. -f1)"
		printf '  owner    : %s\n' "$(stat -c '%U:%G' "$file")"
		local json
		json=$($Swtpm socket $([[ $ver == 2.0 ]] && echo --tpm2) \
			--tpmstate "dir=$dir" --print-info 31 2>/dev/null)
		if [[ -n $json ]]; then
			python3 - "$json" <<-'PY' 2>/dev/null || printf '  identity : %s(could not parse)%s\n' "$C_DIM" "$C_RESET"
				import json, sys
				d = json.loads(sys.argv[1])
				a = d.get("TPMAttributes", {})
				s = d.get("TPMSpecification", {})
				print(f"  identity : manufacturer={a.get('manufacturer')}  model={a.get('model')}  version={a.get('version')}")
				print(f"  spec     : family={s.get('family')} level={s.get('level')} revision={s.get('revision')}")
			PY
		fi
	else
		printf '  %s(no state -- libvirt would manufacture one on next VM start)%s\n' "$C_DIM" "$C_RESET"
	fi
	local n
	n=$(find "$dir" -maxdepth 1 -name '*.permall.bak.*' 2>/dev/null | wc -l)
	printf '  backups  : %s\n' "$n"
	rule
}

# ------------------------------------------------- physical TPM adoption ---

# What identity is currently compiled into libtpms (this is what the vTPM
# reports -- it comes from the binary, NOT from the vTPM state file).
compiled_identity() {
	[[ -f $IdentityHeader ]] || {
		echo "(no $IdentityHeader -- never generated)"
		return 1
	}
	local mfg model fw
	mfg=$(grep -oP 'TPM_IDENT_MANUFACTURER_JSON_ID\s+"\K[^"]+' "$IdentityHeader" 2>/dev/null)
	model=$(grep -oP 'TPM_IDENT_MODEL_JSON_TPM2\s+"\K[^"]+' "$IdentityHeader" 2>/dev/null)
	fw=$(grep -oP 'TPM_IDENT_FIRMWARE_V1\s+\(0x\K[0-9A-Fa-f]+' "$IdentityHeader" 2>/dev/null)
	printf 'manufacturer=id:%s  model=%s  firmware=id:%s' \
		"${mfg:-?}" "${model:-?}" "${fw:-?}"
}

# Enumerate real TPM chips on the board. One line per chip:
#   <devnode>\t<chip>\t<hardware id>
# Prefers /dev/tpmrmN (kernel resource manager, shareable) over /dev/tpmN
# (exclusive -- a single open blocks everything else).
list_tpm_chips() {
	local chip name idx dev desc
	for chip in /sys/class/tpm/tpm*; do
		[[ -e $chip ]] || continue
		name=$(basename "$chip")
		idx=${name#tpm}
		dev=""
		[[ -c /dev/tpmrm$idx ]] && dev="/dev/tpmrm$idx"
		[[ -z $dev && -c /dev/$name ]] && dev="/dev/$name"
		[[ -n $dev ]] || continue
		desc="?"
		[[ -e $chip/device ]] && desc=$(basename "$(readlink -f "$chip/device")")
		if [[ -r $chip/device/description ]]; then
			desc="$desc, $(<"$chip/device/description")"
		fi
		printf '%s\t%s\t%s\n' "$dev" "$name" "$desc"
	done
}

# Read-only identity probe so the chooser can show who each chip actually is.
probe_chip() {
	local dev=$1 out mfg_raw mfg_val
	out=$(TPM2TOOLS_DEVICE="$dev" tpm2 getcap properties-fixed 2>/dev/null) || {
		echo "unreadable"
		return 1
	}
	mfg_raw=$(grep -F TPM2_PT_MANUFACTURER -A3 <<<"$out" | grep -Eo 'raw:\s*0x[0-9A-Fa-f]+' | grep -Eo '0x[0-9A-Fa-f]+' | head -1)
	mfg_val=$(grep -F TPM2_PT_MANUFACTURER -A3 <<<"$out" | grep -Eo 'value:\s*"[^"]*"' | sed 's/.*"\(.*\)"/\1/' | head -1)
	if [[ -z $mfg_raw ]]; then
		echo "no TPM2 fixed properties"
		return 1
	fi
	printf '%s (%s)' "${mfg_val:-?}" "$mfg_raw"
}

adopt_physical_tpm() {
	local -a devs names descs
	local line dev name desc

	command -v tpm2 >/dev/null || {
		fail "tpm2 not found -- install tpm2-tools (pacman -S tpm2-tools)."
		return 1
	}
	[[ -x $DumpScript ]] || { fail "missing $DumpScript"; return 1; }
	[[ -x $GenScript ]] || { fail "missing $GenScript"; return 1; }
	[[ -x $XetalTpm ]] || { fail "missing $XetalTpm"; return 1; }

	while IFS=$'\t' read -r dev name desc; do
		devs+=("$dev")
		names+=("$name")
		descs+=("$desc")
	done < <(list_tpm_chips)

	if ((${#devs[@]} == 0)); then
		echo
		fail "No physical TPM found under /sys/class/tpm."
		warn "Enable the TPM / fTPM in firmware (AMD: 'AMD CPU fTPM'), then retry."
		return 1
	fi

	echo
	rule
	printf '%sPhysical TPM chips on this board%s\n' "$C_BOLD" "$C_RESET"
	local i
	for i in "${!devs[@]}"; do
		printf '  %d) %-14s %s(%s, %s)%s\n' "$((i + 1))" "${devs[i]}" \
			"$C_DIM" "${names[i]}" "${descs[i]}" "$C_RESET"
		printf '       identity: %s\n' "$(probe_chip "${devs[i]}")"
	done
	rule
	printf '  currently compiled into libtpms: %s\n' "$(compiled_identity)"

	local sel=1
	if ((${#devs[@]} > 1)); then
		echo
		printf '%sWhich chip do you want to dump and impersonate?%s\n' "$C_BOLD" "$C_RESET"
		while true; do
			read -r -p "  > [1] " sel
			sel=${sel:-1}
			[[ $sel =~ ^[0-9]+$ ]] && ((sel >= 1 && sel <= ${#devs[@]})) && break
			fail "Enter a number between 1 and ${#devs[@]}."
		done
	else
		info "Only one TPM chip present -- using ${devs[0]}."
	fi
	local chosen=${devs[sel - 1]}

	# --- dump into a temp file first; nothing is committed until confirmed ---
	local tmpenv
	tmpenv=$(mktemp) || return 1
	echo
	info "Dumping fixed properties from $chosen ..."
	if ! TPM2TOOLS_DEVICE="$chosen" bash "$DumpScript" >"$tmpenv" 2>/tmp/tpmdump.err; then
		fail "dump failed:"
		sed 's/^/    /' /tmp/tpmdump.err >&2
		rm -f "$tmpenv" /tmp/tpmdump.err
		return 1
	fi
	rm -f /tmp/tpmdump.err

	echo
	printf '%sDumped from %s%s\n' "$C_BOLD" "$chosen" "$C_RESET"
	grep -vE '^\s*#' "$tmpenv" | sed 's/^/    /'

	# dump-real-tpm.sh does not emit the human model strings; the generator
	# derives "<LABEL> fTPM" from the manufacturer fourcc if we leave them out.
	local mfg_hex label default_model model
	mfg_hex=$(grep -oP '^TPM2_PT_MANUFACTURER=\K.*' "$tmpenv")
	label=$(python3 -c "
import sys
v = int(sys.argv[1], 16)
b = bytes([(v >> 24) & 255, (v >> 16) & 255, (v >> 8) & 255, v & 255])
print(''.join(chr(x) if 32 <= x < 127 else '' for x in b).strip() or 'TPM')
" "$mfg_hex" 2>/dev/null) || label="TPM"
	default_model="$label fTPM"

	echo
	printf '%sModel string the vTPM will report (TPM 2.0)%s\n' "$C_BOLD" "$C_RESET"
	printf '  %sblank = %s%s\n' "$C_DIM" "$default_model" "$C_RESET"
	read -r -p "  > [$default_model] " model
	model=${model:-$default_model}

	# %q, not bare interpolation: gen-tpm-vendor-identity-h.sh *sources* this
	# file, so "MODEL=AMD fTPM" would run `fTPM` as a command and abort.
	{
		printf 'TPM_IDENT_MODEL_JSON_TPM2=%q\n' "$model"
		printf 'TPM_IDENT_MODEL_JSON_TPM12=%q\n' "$label"
	} >>"$tmpenv"

	echo
	rule
	printf '%sAdopt this identity?%s\n' "$C_BOLD" "$C_RESET"
	printf '  from   : %s\n' "$(compiled_identity)"
	# lowercase so it lines up with the "from" line and a no-op adoption is
	# visibly a no-op rather than looking like a change
	local mfg_id="${mfg_hex#0x}"
	printf '  to     : manufacturer=id:%s  model=%s\n' "${mfg_id,,}" "$model"
	printf '  writes : %s\n' "$DumpEnv"
	printf '           %s\n' "$IdentityHeader"
	printf '  then   : %s --no-tpm-dump  (rebuilds libtpms + swtpm)\n' "$(basename "$XetalTpm")"
	rule
	warn "The identity is compiled into libtpms, so after the rebuild your"
	warn "EXISTING vTPM reports the new chip too -- no reconstruction needed."
	warn "The rebuild takes a few minutes and restarts libvirtd. VM must be off."
	echo
	local confirm
	read -r -p "$(printf '%sType %syes%s to dump, regenerate and rebuild: %s' "$C_BOLD" "$C_RED" "$C_RESET$C_BOLD" "$C_RESET")" confirm
	if [[ ${confirm,,} != yes ]]; then
		rm -f "$tmpenv"
		info "Aborted -- nothing was written, nothing rebuilt."
		return 1
	fi

	# --- commit ---
	local stamp
	stamp=$(date +%Y%m%d-%H%M%S)
	[[ -f $DumpEnv ]] && cp -a "$DumpEnv" "${DumpEnv}.bak.${stamp}" &&
		good "backed up $(basename "$DumpEnv") -> $(basename "$DumpEnv").bak.${stamp}"
	[[ -f $IdentityHeader ]] && cp -a "$IdentityHeader" "${IdentityHeader}.bak.${stamp}" &&
		good "backed up $(basename "$IdentityHeader") -> $(basename "$IdentityHeader").bak.${stamp}"

	{
		echo "# TPM_REAL_DUMP written by tpm-reconstruct.sh on $(date -Is)"
		echo "# Source chip: $chosen (${names[sel - 1]}, ${descs[sel - 1]})"
		cat "$tmpenv"
	} >"$DumpEnv.new" && mv "$DumpEnv.new" "$DumpEnv"
	rm -f "$tmpenv"
	good "wrote $DumpEnv"

	info "Regenerating $(basename "$IdentityHeader") ..."
	if ! bash "$GenScript" "$DumpEnv" "$IdentityHeader"; then
		fail "header generation failed -- restoring backups."
		[[ -f ${DumpEnv}.bak.${stamp} ]] && cp -a "${DumpEnv}.bak.${stamp}" "$DumpEnv"
		[[ -f ${IdentityHeader}.bak.${stamp} ]] && cp -a "${IdentityHeader}.bak.${stamp}" "$IdentityHeader"
		return 1
	fi
	good "new header identity: $(compiled_identity)"

	echo
	info "Rebuilding libtpms + swtpm (this takes a few minutes)..."
	rule
	if ! bash "$XetalTpm" --no-tpm-dump; then
		rule
		fail "Rebuild FAILED. The old binaries are still installed and working."
		warn "Header/env backups kept with suffix .bak.${stamp} -- restore them and"
		warn "re-run '$XetalTpm --no-tpm-dump' to get back to the previous identity."
		return 1
	fi
	rule

	echo
	info "Verifying what the rebuilt swtpm now reports..."
	local probe
	probe=$(mktemp -d)
	if "$SwtpmSetup" --tpm2 --tpm-state "$probe" --vmid probe --overwrite \
		--pcr-banks sha256 --tpm "$Swtpm socket" >/dev/null 2>&1; then
		"$Swtpm" socket --tpm2 --tpmstate "dir=$probe" --print-info 31 2>/dev/null |
			python3 -c "
import json, sys
a = json.load(sys.stdin).get('TPMAttributes', {})
print(f\"  vTPM now reports: manufacturer={a.get('manufacturer')}  model={a.get('model')}  version={a.get('version')}\")
" || warn "could not parse verification output"
	else
		warn "verification probe failed (the rebuild itself succeeded)."
	fi
	rm -rf "$probe"

	echo
	good "Identity adopted. Start the VM normally -- the existing vTPM already reports it."
	return 0
}

# ------------------------------------------ host algorithm set matching ---
#
# VMAware's VM::TPM technique does not look at identity, NV or certificates.
# It calls TPM2_GetCapability(TPM_CAP_ALGS) and compares the result against a
# hardcoded copy of libtpms' default-v1 algorithm list:
#
#   "rsa,rsa-min-size=1024,tdes,tdes-min-size=128,sha1,hmac,aes,...,
#    sha512,...,sm2,...,ecmqv,...,camellia,camellia-min-size=128,cmac,..."
#
# An exact match means libtpms, because no physical TPM ships that set. On
# this host the surplus is exactly: tdes, sha512, sm2, ecmqv, camellia.
#
# Rather than hardcode those removals, filter libtpms' own default list down
# to what the physical chip actually reports, so the result stays correct if
# the hardware changes. libtpms >= 0.10 accepts this as a "custom" profile.

readonly LIBTPMS_DEFAULT_ALGS="rsa,rsa-min-size=1024,tdes,tdes-min-size=128,sha1,hmac,\
aes,aes-min-size=128,mgf1,keyedhash,xor,sha256,sha384,sha512,\
null,rsassa,rsaes,rsapss,oaep,ecdsa,ecdh,ecdaa,sm2,ecschnorr,ecmqv,\
kdf1-sp800-56a,kdf2,kdf1-sp800-108,ecc,ecc-min-size=192,ecc-nist,\
ecc-bn,ecc-sm2-p256,symcipher,camellia,camellia-min-size=128,cmac,\
ctr,ofb,cbc,cfb,ecb"

# Emit a libtpms Algorithms string restricted to what $1 (a /dev/tpm*) has.
host_algorithm_profile() {
	local dev=$1 curves tok base
	declare -A have=()
	local a
	while read -r a; do
		[[ -n $a ]] && have[${a//_/-}]=1
	done < <(TPM2TOOLS_DEVICE="$dev" tpm2_getcap algorithms 2>/dev/null |
		grep -oE '^[a-z0-9_]+:' | tr -d ':')
	((${#have[@]})) || return 1
	curves=$(TPM2TOOLS_DEVICE="$dev" tpm2_getcap ecc-curves 2>/dev/null)

	local -a out=()
	local IFS=,
	for tok in $LIBTPMS_DEFAULT_ALGS; do
		base=${tok%%=*}
		case $base in
		# TPM_ALG_NULL is structural and never reported by getcap.
		null) out+=("$tok"); continue ;;
		# Curve families are gated on the curve list, not the algorithm list.
		ecc-nist) grep -q "NIST_P" <<<"$curves" && out+=("$tok"); continue ;;
		ecc-bn) grep -q "BN_P" <<<"$curves" && out+=("$tok"); continue ;;
		ecc-sm2-p256) grep -q "SM2_P" <<<"$curves" && out+=("$tok"); continue ;;
		esac
		# "<alg>-min-size=N" rides along with its base algorithm.
		if [[ $tok == *-min-size=* ]]; then
			base=${tok%%-min-size=*}
		fi
		[[ -n ${have[$base]:-} ]] && out+=("$tok")
	done
	echo "${out[*]}"
}

# -------------------------------------------- host fTPM NV layout mirror ---
#
# A freshly manufactured swtpm does NOT look like an AMD fTPM in NV:
#
#   real AMD fTPM : 0x1800100 0x1810008 0x1820002   (platform provisioned)
#                   and NO EK certificate at all
#   stock swtpm   : none of those, but DOES create 0x1c00002 / 0x1c00016 /
#                   0x1c08000 EK and platform certs signed by swtpm-localca
#
# So the vTPM simultaneously lacks indices real silicon has and carries ones
# it does not. Reading a missing index returns TPM_RC_HANDLE rather than the
# auth error a real chip gives, which is a detectable difference.
#
# Rather than hardcode the indices, mirror whatever THIS host's chip has in
# the TCG platform manufacturer range 0x01800000..0x01BFFFFF, so the layout
# stays correct if the hardware changes.

readonly NV_PLATFORM_LO=$((0x01800000))
readonly NV_PLATFORM_HI=$((0x01BFFFFF))

# Emit "index size attrs" for each host index in the platform range.
# Status-only bits are stripped: they are set by the TPM, not at define time.
host_nv_targets() {
	local dev=$1 idx size attrs
	TPM2TOOLS_DEVICE="$dev" tpm2_nvreadpublic 2>/dev/null | awk '
		/^0x[0-9a-fA-F]+:/ { idx=$1; sub(":","",idx); next }
		/^[[:space:]]+friendly:/ && idx && !seen_attr[idx] && $2 ~ /\|/ {
			attrs[idx]=$2; seen_attr[idx]=1; next }
		/^[[:space:]]+size:/ && idx { size[idx]=$2; order[++n]=idx; idx=""; next }
		END { for (i=1;i<=n;i++) printf "%s %s %s\n", order[i], size[order[i]], attrs[order[i]] }
	' | while read -r idx size attrs; do
		[[ -n $idx && -n $size ]] || continue
		local v=$((idx))
		((v >= NV_PLATFORM_LO && v <= NV_PLATFORM_HI)) || continue
		# drop TPM-maintained status bits; they cannot be requested
		attrs=$(tr '|' '\n' <<<"$attrs" |
			grep -vxE 'written|writelocked|readlocked|platformcreate' | paste -sd'|')
		printf '%s %s %s\n' "$idx" "$size" "$attrs"
	done
}

# Provision the missing indices into a swtpm state directory.
# $1 = state dir, $2 = "2.0"|"1.2"
apply_host_nv_layout() {
	local dir=$1 ver=$2
	[[ $ver == 2.0 ]] || { warn "NV mirroring only applies to TPM 2.0."; return 1; }
	command -v tpm2_nvreadpublic >/dev/null || { fail "tpm2-tools missing."; return 1; }

	local hostdev=""
	local chip name idx
	for chip in /sys/class/tpm/tpm*; do
		[[ -e $chip ]] || continue
		name=$(basename "$chip"); idx=${name#tpm}
		[[ -c /dev/tpmrm$idx ]] && { hostdev="/dev/tpmrm$idx"; break; }
		[[ -c /dev/$name ]] && { hostdev="/dev/$name"; break; }
	done
	[[ -n $hostdev ]] || { fail "no physical TPM to mirror from."; return 1; }

	local -a tgt
	mapfile -t tgt < <(host_nv_targets "$hostdev")
	if ((${#tgt[@]} == 0)); then
		warn "host chip exposes no platform-range NV indices; nothing to mirror."
		return 0
	fi

	echo
	rule
	printf '%sMirroring host fTPM NV layout%s  (source: %s)\n' "$C_BOLD" "$C_RESET" "$hostdev"
	printf '  %-12s %-6s %s\n' "INDEX" "SIZE" "ATTRIBUTES"
	local line
	for line in "${tgt[@]}"; do printf '  %-12s %-6s %s\n' $line; done
	rule

	# Serve the state so tpm2-tools can talk to it. Short socket paths: the
	# sun_path limit is 108 bytes and state dirs can be long.
	local sock
	sock=$(mktemp -d /tmp/swtnv.XXXX) || return 1
	# The swtpm TCTI derives the control socket as <data path>.ctrl, so the
	# ctrl socket MUST be named s.ctrl next to the data socket s.
	"$Swtpm" socket --tpm2 --tpmstate "dir=$dir" \
		--ctrl "type=unixio,path=$sock/s.ctrl" --server "type=unixio,path=$sock/s" \
		--flags not-need-init,startup-clear >"$sock/log" 2>&1 &
	local pid=$!
	# Wait for the listener. This needs a real delay: a bare [[ -S ]] spin
	# completes in microseconds, long before swtpm has created the socket.
	local i
	for i in $(seq 1 100); do
		[[ -S $sock/s ]] && break
		sleep 0.05
	done
	if [[ ! -S $sock/s ]]; then
		fail "could not start swtpm on the state dir:"
		sed 's/^/    /' "$sock/log" >&2
		kill $pid 2>/dev/null; rm -rf "$sock"
		return 1
	fi
	export TPM2TOOLS_TCTI="swtpm:path=$sock/s"

	local existing created=0 skipped=0 failed=0
	existing=$(tpm2_nvreadpublic 2>/dev/null | grep -oE '^0x[0-9a-fA-F]+' | tr -d ':')

	local ix sz at
	for line in "${tgt[@]}"; do
		read -r ix sz at <<<"$line"
		if grep -qix "$ix" <<<"$existing"; then
			printf '  %sskip%s  %s (already present)\n' "$C_DIM" "$C_RESET" "$ix"
			((skipped++)); continue
		fi
		if tpm2_nvdefine "$ix" -C o -s "$sz" -a "$at" >/dev/null 2>&1; then
			# Defining is not enough: on the real chip every one of these
			# carries the "written" attribute, i.e. it holds data. A defined
			# but never written index reads back TPM_RC_NV_UNINITIALIZED,
			# which is still distinguishable. Seed it so "written" gets set.
			# Which authorisation works depends on the index's own attributes.
			local auth="-C o" wrote="no"
			[[ $at == *ownerwrite* ]] || auth="-C $ix"
			if [[ $at == *"nt=0x1"* ]]; then
				tpm2_nvincrement "$ix" $auth >/dev/null 2>&1 && wrote="yes"
			else
				head -c "$sz" /dev/zero >"$sock/seed" 2>/dev/null
				tpm2_nvwrite "$ix" $auth -i "$sock/seed" >/dev/null 2>&1 && wrote="yes"
			fi
			printf '  %sok%s    %s  size=%s  written=%s\n' \
				"$C_GREEN" "$C_RESET" "$ix" "$sz" "$wrote"
			[[ $wrote == no ]] && warn "    $ix defined but could not be seeded ($at)"
			((created++))
		else
			printf '  %sFAIL%s  %s  (%s)\n' "$C_RED" "$C_RESET" "$ix" "$at"
			((failed++))
		fi
	done

	unset TPM2TOOLS_TCTI
	kill $pid 2>/dev/null; wait $pid 2>/dev/null
	rm -rf "$sock"

	echo
	good "NV mirror: $created created, $skipped already present, $failed failed"
	((failed == 0))
}

# ------------------------------------------------------------ verification ---
#
# Everything below was a real detection at some point. Re-checking is cheap;
# re-diagnosing costs a shutdown, a reconstruct and a guest boot each time.
# Run this after any reconstruct, or after touching swtpm/libtpms.
#
# NOT covered here, because it lives in firmware rather than the vTPM:
#   * OVMF PEIFV/DXEFV blob bounds measured into PCR 0
#   * EV_S_CRTM_VERSION payload (PcdFirmwareVersionString)
# Those are fixed in ovmf_modified_secure and only change if OVMF is rebuilt.

verify_against_host() {
	local ver=$1 dir sock pid rc=0
	[[ $ver == 2.0 ]] || { warn "verification only implemented for TPM 2.0."; return 1; }
	dir=$(state_dir_for "$ver")
	[[ -f $(state_file_for "$ver") ]] || { fail "no vTPM state to verify."; return 1; }

	local hostdev="" chip name idx
	for chip in /sys/class/tpm/tpm*; do
		[[ -e $chip ]] || continue
		name=$(basename "$chip"); idx=${name#tpm}
		[[ -c /dev/tpmrm$idx ]] && { hostdev="/dev/tpmrm$idx"; break; }
		[[ -c /dev/$name ]] && { hostdev="/dev/$name"; break; }
	done
	[[ -n $hostdev ]] || { fail "no physical TPM to compare against."; return 1; }

	sock=$(mktemp -d /tmp/swtv.XXXX) || return 1
	"$Swtpm" socket --tpm2 --tpmstate "dir=$dir" \
		--ctrl "type=unixio,path=$sock/s.ctrl" --server "type=unixio,path=$sock/s" \
		--flags not-need-init,startup-clear >"$sock/log" 2>&1 &
	pid=$!
	local i
	for i in $(seq 1 100); do [[ -S $sock/s ]] && break; sleep 0.05; done
	if [[ ! -S $sock/s ]]; then
		fail "could not open the vTPM state (is the VM running?)"
		sed 's/^/    /' "$sock/log" >&2
		kill $pid 2>/dev/null; rm -rf "$sock"
		return 1
	fi
	export TPM2TOOLS_TCTI="swtpm:path=$sock/s"

	echo
	rule
	printf '%svTPM vs physical chip (%s)%s\n' "$C_BOLD" "$hostdev" "$C_RESET"
	rule

	# 1. Algorithm set. An exact match with libtpms' default profile is the
	#    VM::TPM fingerprint; matching the real chip both defeats it and is
	#    correct in its own right.
	local ha va
	ha=$(TPM2TOOLS_DEVICE="$hostdev" tpm2_getcap algorithms 2>/dev/null | grep -oE '^[a-z0-9_]+:' | tr -d ':' | sort | tr '\n' ' ')
	va=$(tpm2_getcap algorithms 2>/dev/null | grep -oE '^[a-z0-9_]+:' | tr -d ':' | sort | tr '\n' ' ')
	if [[ $ha == "$va" ]]; then
		printf '  %sPASS%s algorithms match (%s entries)\n' "$C_GREEN" "$C_RESET" "$(wc -w <<<"$va")"
	else
		printf '  %sFAIL%s algorithm sets differ\n' "$C_RED" "$C_RESET"
		printf '        vTPM extra : %s\n' "$(comm -13 <(tr ' ' '\n' <<<"$ha" | sort -u) <(tr ' ' '\n' <<<"$va" | sort -u) | tr '\n' ' ')"
		printf '        vTPM missing: %s\n' "$(comm -23 <(tr ' ' '\n' <<<"$ha" | sort -u) <(tr ' ' '\n' <<<"$va" | sort -u) | tr '\n' ' ')"
		printf '        fix: reconstruct with provisioning profile 1\n'
		rc=1
	fi

	# 2. Platform-range NV indices the real chip carries.
	local hn vn missing=""
	hn=$(TPM2TOOLS_DEVICE="$hostdev" tpm2_nvreadpublic 2>/dev/null | grep -oE '^0x[0-9a-f]+' | tr -d ':')
	vn=$(tpm2_nvreadpublic 2>/dev/null | grep -oE '^0x[0-9a-f]+' | tr -d ':')
	local ix v
	for ix in $hn; do
		v=$((ix))
		((v >= NV_PLATFORM_LO && v <= NV_PLATFORM_HI)) || continue
		grep -qix "$ix" <<<"$vn" || missing+="$ix "
	done
	if [[ -z $missing ]]; then
		printf '  %sPASS%s platform-range NV indices all present\n' "$C_GREEN" "$C_RESET"
	else
		printf '  %sFAIL%s missing NV indices: %s\n' "$C_RED" "$C_RESET" "$missing"
		printf '        fix: menu option 6 (mirror NV layout), no rebuild needed\n'
		rc=1
	fi

	# 3. EK certificate. Removing it to imitate the real chip's empty
	#    0x1c00002 made Windows report Ready For Attestation: False, so it
	#    must be present even though real AMD silicon stores it elsewhere.
	if grep -qi "0x1c00002" <<<"$vn"; then
		printf '  %sPASS%s EK certificate present (Windows attestation)\n' "$C_GREEN" "$C_RESET"
	else
		printf '  %sFAIL%s no EK certificate at 0x1c00002\n' "$C_RED" "$C_RESET"
		printf '        Windows will report Ready For Attestation: False\n'
		printf '        fix: reconstruct with provisioning profile 1\n'
		rc=1
	fi

	# 4. Vendor identity, which comes from libtpms, not from this state.
	local hm vm_
	hm=$(TPM2TOOLS_DEVICE="$hostdev" tpm2_getcap properties-fixed 2>/dev/null |
		awk '/^TPM2_PT_MANUFACTURER:/{f=1;next} f&&/raw:/{print $2;exit}')
	vm_=$(tpm2_getcap properties-fixed 2>/dev/null |
		awk '/^TPM2_PT_MANUFACTURER:/{f=1;next} f&&/raw:/{print $2;exit}')
	if [[ ${hm,,} == "${vm_,,}" ]]; then
		printf '  %sPASS%s manufacturer matches (%s)\n' "$C_GREEN" "$C_RESET" "$vm_"
	else
		printf '  %sFAIL%s manufacturer %s vs host %s\n' "$C_RED" "$C_RESET" "$vm_" "$hm"
		printf '        fix: menu option 5 (adopt physical TPM identity, rebuilds libtpms)\n'
		rc=1
	fi

	unset TPM2TOOLS_TCTI
	kill $pid 2>/dev/null; wait $pid 2>/dev/null
	rm -rf "$sock"
	rule
	((rc == 0)) && good "vTPM is consistent with the physical chip." ||
		warn "Differences found; see the fix hints above."
	return $rc
}

# ----------------------------------------------------------------- actions ---

do_backup() {
	local ver=$1 file stamp
	file=$(state_file_for "$ver")
	[[ -f $file ]] || {
		warn "nothing to back up (no TPM $ver state)."
		return 1
	}
	stamp=$(date +%Y%m%d-%H%M%S)
	cp -a "$file" "${file}.bak.${stamp}" || {
		fail "backup failed."
		return 1
	}
	good "backed up -> ${file}.bak.${stamp}"
	return 0
}

do_restore() {
	local ver=$1 dir file backups choice
	dir=$(state_dir_for "$ver")
	file=$(state_file_for "$ver")
	mapfile -t backups < <(find "$dir" -maxdepth 1 -name '*.permall.bak.*' -printf '%T@ %p\n' 2>/dev/null |
		sort -rn | cut -d' ' -f2-)
	if ((${#backups[@]} == 0)); then
		warn "no backups found in $dir"
		return 1
	fi
	echo
	printf '%sAvailable backups (newest first)%s\n' "$C_BOLD" "$C_RESET"
	local i
	for i in "${!backups[@]}"; do
		printf '  %d) %s  %s(%s bytes, %s)%s\n' "$((i + 1))" "$(basename "${backups[i]}")" \
			"$C_DIM" "$(stat -c '%s' "${backups[i]}")" "$(stat -c '%y' "${backups[i]}" | cut -d. -f1)" "$C_RESET"
	done
	read -r -p "  > [1] " choice
	choice=${choice:-1}
	[[ $choice =~ ^[0-9]+$ ]] && ((choice >= 1 && choice <= ${#backups[@]})) || {
		fail "invalid selection."
		return 1
	}
	local src=${backups[choice - 1]} owner
	owner=$(detect_owner "$dir")
	cp -a "$src" "$file" || {
		fail "restore failed."
		return 1
	}
	chown "$owner" "$file"
	chmod 0600 "$file"
	good "restored $(basename "$src") -> $(basename "$file")"
	return 0
}

do_reconstruct() {
	local ver=$1
	local profile="default-v1" banks="sha256" keysize="2048"
	local ek_cert plat_cert lock_nvram backup_first confirm

	if [[ $ver == 2.0 ]]; then
		ask_choice profile "TPM 2.0 profile" 1 "default-v1" "default-v2" "null"
		ask_choice banks "Active PCR banks" 1 \
			"sha256" "sha1,sha256" "sha256,sha384" "sha1,sha256,sha384,sha512"
		ask_choice keysize "RSA EK key size" 1 "2048" "3072" "4096"
	fi
	echo
	# Provisioning profile. The default matters: stock swtpm creates EK and
	# platform certificates that a real AMD fTPM does not have (it has no
	# 0x1c00002 at all), and omits the platform range NV indices that it does.
	# NOTE, measured in the guest rather than assumed: dropping the EK
	# certificate to imitate the real chip's empty 0x1c00002 made Windows
	# WORSE, not better. tpmtool went from
	#     Ready For Attestation: True / Is Capable For Attestation: True
	# to  Ready For Attestation: False / Is Capable For Attestation: False
	#     Information Flags Description: INFORMATION_EK_CERTIFICATE
	# and Get-TpmEndorsementKeyInfo dropped to ManufacturerCertificates: 0.
	# A real AMD machine reports attestation capable, so the certificate has
	# to stay even though the real chip does not carry it in that NV index.
	# Mirroring the NV layout is still correct and is kept.
	local provprofile mirror_nv
	ask_choice provprofile "Provisioning profile" 1 \
		"match this host's physical fTPM (algorithms + NV layout, keep EK certs)" \
		"swtpm defaults (EK + platform certs, no NV mirroring)" \
		"custom (ask me about each)"

	local custom_algs=""
	case $provprofile in
	"match this host's"*)
		ek_cert=yes; plat_cert=yes; mirror_nv=yes
		info "Host NV layout mirrored; EK/platform certs kept (Windows needs them)."
		if [[ $ver == 2.0 ]]; then
			local hdev=""
			local c n i
			for c in /sys/class/tpm/tpm*; do
				[[ -e $c ]] || continue
				n=$(basename "$c"); i=${n#tpm}
				[[ -c /dev/tpmrm$i ]] && { hdev="/dev/tpmrm$i"; break; }
				[[ -c /dev/$n ]] && { hdev="/dev/$n"; break; }
			done
			if [[ -n $hdev ]] && custom_algs=$(host_algorithm_profile "$hdev") &&
				[[ -n $custom_algs ]]; then
				good "Algorithm set restricted to this chip's, defeating the"
				good "libtpms default-profile fingerprint (VM::TPM)."
			else
				warn "Could not read host algorithms; keeping libtpms defaults."
				custom_algs=""
			fi
		fi
		;;
	"swtpm defaults"*)
		ek_cert=yes; plat_cert=yes; mirror_nv=no
		;;
	*)
		ask_yn ek_cert "Create EK certificate? (No breaks Windows attestation)" Y
		ask_yn plat_cert "Create platform certificate?" Y
		ask_yn mirror_nv "Mirror this host's fTPM NV layout?" Y
		;;
	esac

	ask_yn lock_nvram "Lock NVRAM after setup?" Y
	ask_yn backup_first "Back up the current TPM state first?" Y

	local dir file owner
	dir=$(state_dir_for "$ver")
	file=$(state_file_for "$ver")
	owner=$(detect_owner "$dir")

	# Build the swtpm_setup argv.
	local args=(--tpm-state "$dir" --vmid "$Domain" --overwrite --createek --tpm "$Swtpm socket")
	if [[ $ver == 2.0 ]]; then
		args+=(--tpm2 --pcr-banks "$banks" --rsa-keysize "$keysize")
		if [[ -n $custom_algs ]]; then
			# A custom profile carries its own algorithm list, so it replaces
			# --profile-name rather than accompanying it.
			args+=(--profile "{\"Name\":\"custom\",\"Algorithms\":\"$custom_algs\"}")
		else
			args+=(--profile-name "$profile")
		fi
	fi
	[[ $ek_cert == yes ]] && args+=(--create-ek-cert)
	[[ $plat_cert == yes ]] && args+=(--create-platform-cert)
	# --lock-nvram is applied by swtpm_setup during manufacture, which would
	# then prevent us defining the mirrored indices afterwards. The host's
	# platform-range indices carry no globallock attribute anyway, so skipping
	# the lock is also the more faithful choice when mirroring.
	if [[ $lock_nvram == yes ]]; then
		if [[ $mirror_nv == yes ]]; then
			lock_nvram="no (skipped: conflicts with NV mirroring)"
		else
			args+=(--lock-nvram)
		fi
	fi

	echo
	rule
	printf '%sAbout to reconstruct the vTPM for domain "%s"%s\n' "$C_BOLD" "$Domain" "$C_RESET"
	printf '  uuid       : %s\n' "$Uuid"
	printf '  state dir  : %s\n' "$dir"
	printf '  version    : TPM %s\n' "$ver"
	if [[ $ver == 2.0 ]]; then
		printf '  profile    : %s\n' "$profile"
		printf '  pcr banks  : %s\n' "$banks"
		printf '  rsa keysize: %s\n' "$keysize"
	fi
	printf '  ek cert    : %s%s\n' "$ek_cert" \
		"$([[ $ek_cert == no ]] && echo '   (real AMD fTPM has none)' || echo '')"
	printf '  plat cert  : %s\n' "$plat_cert"
	printf '  mirror NV  : %s%s\n' "$mirror_nv" \
		"$([[ $mirror_nv == yes ]] && echo '   (copy host platform-range indices)' || echo '')"
	printf '  lock nvram : %s\n' "$lock_nvram"
	printf '  backup     : %s\n' "$backup_first"
	printf '  owner      : %s\n' "$owner"
	echo
	printf '  %s%s %s%s\n' "$C_DIM" "$SwtpmSetup" "${args[*]}" "$C_RESET"
	rule
	warn "This destroys the current vTPM. Windows will see a brand-new chip:"
	warn "  BitLocker / Windows Hello / TPM-sealed secrets in the guest will be lost."
	warn "  Have your BitLocker recovery key ready if it is enabled."
	echo
	read -r -p "$(printf '%sType %syes%s to proceed: %s' "$C_BOLD" "$C_RED" "$C_RESET$C_BOLD" "$C_RESET")" confirm
	if [[ ${confirm,,} != yes ]]; then
		info "Aborted -- nothing was changed."
		return 1
	fi

	if [[ $backup_first == yes ]]; then
		do_backup "$ver" || warn "continuing without a backup."
	fi

	mkdir -p "$dir"
	rm -f "$file" "$dir/.lock"

	echo
	info "Running swtpm_setup..."
	rule
	if ! "$SwtpmSetup" "${args[@]}"; then
		fail "swtpm_setup failed -- the vTPM was NOT reconstructed."
		warn "Restore a backup with menu option 3 if the old state was removed."
		return 1
	fi
	rule

	# Mirror before the chown so any files swtpm creates end up owned correctly.
	if [[ $mirror_nv == yes ]]; then
		apply_host_nv_layout "$dir" "$ver" ||
			warn "NV mirroring incomplete: the vTPM still differs from the host chip."
	fi

	chown -R "$owner" "$dir"
	chmod 0700 "$dir"
	[[ -f $file ]] && chmod 0600 "$file"
	good "vTPM reconstructed and owned by $owner"

	echo
	info "Verifying the new chip identity..."
	show_current "$ver"

	# Always verify. Every axis checked here was a live detection at some
	# point; catching a regression now costs seconds, catching it later costs
	# a shutdown, a reconstruct and a guest boot.
	verify_against_host "$ver" || true

	good "Done. Start the VM normally (win10 / vmstart)."
	return 0
}

# -------------------------------------------------------------------- main ---

clear 2>/dev/null || true
printf '%s' "$C_BOLD"
cat <<'BANNER'
==============================================================
             Xetal Engine - TPM Chip Reconstruction
==============================================================
BANNER
printf '%s' "$C_RESET"
printf '  domain : %s\n  uuid   : %s\n  swtpm  : %s\n' "$Domain" "$Uuid" "$Swtpm"
printf '  libtpms: %s\n' "$(compiled_identity)"

DomState=$(virsh --connect qemu:///system domstate "$Domain" 2>/dev/null)
printf '  state  : %s\n' "$DomState"
if [[ $DomState != "shut off" ]]; then
	echo
	die "domain '$Domain' is '$DomState'. Shut it down before touching the vTPM."
fi

ask_choice TpmVersion "Which TPM does this domain use?" 1 "2.0" "1.2"
show_current "$TpmVersion"

while true; do
	echo
	printf '%sWhat do you want to do?%s\n' "$C_BOLD" "$C_RESET"
	printf '  1) Reconstruct the vTPM   %s(new chip, keeps the current identity)%s\n' "$C_DIM" "$C_RESET"
	printf '  2) Back up the current vTPM state\n'
	printf '  3) Restore the vTPM from a backup\n'
	printf '  4) Show current vTPM info again\n'
	printf '  5) Adopt a PHYSICAL TPM identity   %s(dump a real chip + rebuild)%s\n' "$C_DIM" "$C_RESET"
	printf '  6) Mirror host fTPM NV layout onto the CURRENT vTPM   %s(no rebuild)%s\n' "$C_DIM" "$C_RESET"
	printf '  7) %sVerify this vTPM against the physical chip%s   %s(read only)%s\n' \
		"$C_GREEN" "$C_RESET" "$C_DIM" "$C_RESET"
	printf '  8) %sRe-provision the PHYSICAL TPM EK%s  %s(real hardware HWID, finite writes)%s\n' \
		"$C_RED" "$C_RESET" "$C_DIM" "$C_RESET"
	printf '  9) Quit without changing anything\n'
	read -r -p "  > [9] " Action
	case ${Action:-9} in
	1) do_reconstruct "$TpmVersion" && pause_exit 0 ;;
	2) do_backup "$TpmVersion" ;;
	3) do_restore "$TpmVersion" ;;
	4) show_current "$TpmVersion" ;;
	5) adopt_physical_tpm && pause_exit 0 ;;
	6)
		do_backup "$TpmVersion" || warn "continuing without a backup."
		apply_host_nv_layout "$(state_dir_for "$TpmVersion")" "$TpmVersion"
		chown -R "$(detect_owner "$(state_dir_for "$TpmVersion")")" "$(state_dir_for "$TpmVersion")"
		;;
	7) verify_against_host "$TpmVersion" ;;
	8)
		if [[ -x $HwidScript ]]; then
			"$HwidScript"
		else
			fail "missing $HwidScript"
		fi
		;;
	9)
		info "Nothing changed."
		pause_exit 0
		;;
	*) fail "Enter 1-9." ;;
	esac
done
