#!/usr/bin/env python3
"""Rewrite absolute DT_RUNPATH/DT_RPATH entries to $ORIGIN-relative ones.

Why this exists
---------------
The build hardcodes $PREFIX into every binary's RUNPATH. Move the tree and
swtpm dies with "libswtpm_libtpms.so.0: cannot open shared object file",
because a search-and-replace over the source cannot reach a string baked into
an ELF. Rewriting the RUNPATH relative to $ORIGIN (the directory of the binary
itself) makes the install relocatable, and makes it work with no
LD_LIBRARY_PATH at all.

How it is safe
--------------
$ORIGIN-relative paths are always shorter than the absolute paths they
replace, so the .dynstr entry is overwritten in place and NUL-padded. Nothing
is resized, no section offsets move -- this is the same shrink-only edit
patchelf performs, without the dependency. If a replacement would ever be
longer it is skipped rather than corrupting the file.

Idempotent: entries already using $ORIGIN are left alone, so running it after
every rebuild is free.

    relink-origin.py --prefix /path/to/_install [--quiet]
    relink-origin.py --prefix /path/to/_install file [file...]
"""

import argparse
import os
import re
import subprocess
import sys

# Subdirectories of $PREFIX that can hold ELF objects worth relinking.
SCAN_DIRS = ("bin", "lib", "lib/swtpm", "libexec")

RUNPATH_RE = re.compile(r"Library (?:runpath|rpath): \[([^\]]*)\]")


def is_elf(path):
    try:
        with open(path, "rb") as fh:
            return fh.read(4) == b"\x7fELF"
    except OSError:
        return False


def current_runpath(path):
    """Return the RUNPATH/RPATH string, or None if the binary has none."""
    try:
        out = subprocess.run(["readelf", "-d", "-W", path],
                             capture_output=True, text=True, check=True).stdout
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None
    m = RUNPATH_RE.search(out)
    return m.group(1) if m else None


def dynstr_range(path):
    out = subprocess.run(["readelf", "-S", "-W", path],
                         capture_output=True, text=True, check=True).stdout
    for line in out.splitlines():
        if ".dynstr" not in line:
            continue
        parts = line.replace("[", " ").replace("]", " ").split()
        i = parts.index(".dynstr")
        return int(parts[i + 2], 16), int(parts[i + 3], 16)
    return None


def relativise(runpath, binary, prefix):
    """Map each absolute-under-prefix entry to an $ORIGIN-relative one."""
    binary_dir = os.path.dirname(os.path.abspath(binary))
    out, changed = [], False
    for entry in runpath.split(":"):
        if not entry or entry.startswith("$ORIGIN"):
            out.append(entry)
            continue
        real = os.path.abspath(entry)
        if real == prefix or real.startswith(prefix + os.sep):
            out.append(os.path.join("$ORIGIN", os.path.relpath(real, binary_dir)))
            changed = True
        else:
            # Something outside the install tree -- not ours to rewrite.
            out.append(entry)
    return ":".join(out), changed


def patch(path, old, new, quiet):
    old_b, new_b = old.encode(), new.encode()
    if len(new_b) > len(old_b):
        print(f"  skip {path}: $ORIGIN form is longer than the original "
              f"({len(new_b)} > {len(old_b)} bytes); cannot grow in place",
              file=sys.stderr)
        return False

    rng = dynstr_range(path)
    if rng is None:
        print(f"  skip {path}: no .dynstr section", file=sys.stderr)
        return False
    off, size = rng

    with open(path, "rb") as fh:
        data = bytearray(fh.read())

    # Confine the edit to .dynstr so an identical string living in a debug or
    # comment section is left alone.
    idx = data[off:off + size].find(old_b)
    if idx == -1:
        print(f"  skip {path}: RUNPATH not found in .dynstr", file=sys.stderr)
        return False

    at = off + idx
    data[at:at + len(old_b)] = new_b + b"\0" * (len(old_b) - len(new_b))
    with open(path, "wb") as fh:
        fh.write(bytes(data))
    if not quiet:
        print(f"  {os.path.basename(path)}: {new}")
    return True


def collect(prefix):
    for sub in SCAN_DIRS:
        d = os.path.join(prefix, sub)
        if not os.path.isdir(d):
            continue
        for name in sorted(os.listdir(d)):
            p = os.path.join(d, name)
            # Skip symlinks: the real file is patched via its own entry, and
            # following them would rewrite the same bytes twice.
            if os.path.islink(p) or not os.path.isfile(p):
                continue
            if is_elf(p):
                yield p


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--prefix", required=True, help="install root ($PREFIX)")
    ap.add_argument("--quiet", action="store_true")
    ap.add_argument("files", nargs="*", help="ELF files (default: scan --prefix)")
    args = ap.parse_args()

    prefix = os.path.abspath(args.prefix)
    if not os.path.isdir(prefix):
        print(f"error: no such prefix: {prefix}", file=sys.stderr)
        return 1

    targets = [f for f in args.files if is_elf(f)] if args.files else list(collect(prefix))

    patched = already = 0
    for path in targets:
        rp = current_runpath(path)
        if not rp:
            continue
        new, changed = relativise(rp, path, prefix)
        if not changed:
            already += 1
            continue
        if patch(path, rp, new, args.quiet):
            patched += 1

    if not args.quiet:
        print(f"  relinked {patched}, already relative {already}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
