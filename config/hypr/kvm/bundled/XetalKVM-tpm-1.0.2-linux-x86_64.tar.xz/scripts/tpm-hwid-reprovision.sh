#!/usr/bin/env bash
#
# Re-provision the PHYSICAL TPM's endorsement key -> changes the host's
# TPM-derived hardware identity.
#
#   *** THIS TOUCHES REAL HARDWARE, NOT THE vTPM. ***
#
# The vTPM tooling (tpm-reconstruct.sh) only ever writes files under
# /var/lib/libvirt/swtpm. This script talks to the fTPM/dTPM on the board and
# its effects persist across reinstalls and OS changes. Keep the two straight.
#
# Mechanism: TPM2_Clear regenerates the Endorsement Primary Seed, so every key
# derived from the endorsement hierarchy changes. Creating a new primary and
# persisting it at the conventional EK handle 0x81010001 replaces what
# EK-reading software sees.
#
# Endurance: TPM2_Clear and evictcontrol write NV flash. On an fTPM that is
# backed by limited-write storage, so re-provisioning is NOT free -- every run
# is recorded in hwid-history.log so you can see how often it has been done.
# Use "Probe algorithm support" (which writes nothing) before spending a run.

set -uo pipefail

if [[ ${EUID} -ne 0 ]]; then
	exec sudo bash "$0" "$@"
fi

readonly ScriptDir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
readonly TpmRoot="$(cd -- "$ScriptDir/.." && pwd)"
readonly HistoryLog="$TpmRoot/hwid-history.log"
readonly ArtifactDir="$TpmRoot/hwid-artifacts"
readonly EkHandle="0x81010001"

readonly C_RESET=$'\e[0m' C_BOLD=$'\e[1m' C_DIM=$'\e[2m'
readonly C_RED=$'\e[31m' C_GREEN=$'\e[32m' C_YELLOW=$'\e[33m' C_BLUE=$'\e[36m'

info() { printf '%s[*]%s %s\n' "$C_BLUE" "$C_RESET" "$*"; }
good() { printf '%s[+]%s %s\n' "$C_GREEN" "$C_RESET" "$*"; }
warn() { printf '%s[!]%s %s\n' "$C_YELLOW" "$C_RESET" "$*"; }
fail() { printf '%s[x]%s %s\n' "$C_RED" "$C_RESET" "$*" >&2; }
rule() { printf '%s------------------------------------------------------------%s\n' "$C_DIM" "$C_RESET"; }

pause_exit() {
	echo
	read -r -p "Press Enter to close... " _ || true
	exit "${1:-0}"
}

TpmDev=""

# --------------------------------------------------------------- discovery ---

pick_device() {
	local chip name idx
	for chip in /sys/class/tpm/tpm*; do
		[[ -e $chip ]] || continue
		name=$(basename "$chip")
		idx=${name#tpm}
		[[ -c /dev/tpmrm$idx ]] && { TpmDev="/dev/tpmrm$idx"; return 0; }
		[[ -c /dev/$name ]] && { TpmDev="/dev/$name"; return 0; }
	done
	return 1
}

tpm() { TPM2TOOLS_DEVICE="$TpmDev" "$@"; }

perm_flag() {
	# TPM2_PT_PERMANENT sub-flags come back as "  name:  0/1"
	tpm tpm2_getcap properties-variable 2>/dev/null |
		awk -v k="$1:" '$1 == k { print $2; exit }'
}

supported_hashes() {
	local all avail=()
	all=$(tpm tpm2_getcap algorithms 2>/dev/null | grep -oE '^[a-z0-9_]+:' | tr -d ':')
	local h
	for h in sha1 sha256 sha384 sha512 sm3_256; do
		grep -qx "$h" <<<"$all" && avail+=("$h")
	done
	printf '%s\n' "${avail[@]}"
}

supported_keyalgs() {
	local all curves avail=()
	all=$(tpm tpm2_getcap algorithms 2>/dev/null | grep -oE '^[a-z0-9_]+:' | tr -d ':')
	if grep -qx rsa <<<"$all"; then
		# The TPM does not advertise usable RSA moduli; these get probed.
		avail+=(rsa2048 rsa3072 rsa4096 rsa1024)
	fi
	if grep -qx ecc <<<"$all"; then
		curves=$(tpm tpm2_getcap ecc-curves 2>/dev/null)
		grep -q NIST_P192 <<<"$curves" && avail+=(ecc192)
		grep -q NIST_P224 <<<"$curves" && avail+=(ecc224)
		grep -q NIST_P256 <<<"$curves" && avail+=(ecc256)
		grep -q NIST_P384 <<<"$curves" && avail+=(ecc384)
		grep -q NIST_P521 <<<"$curves" && avail+=(ecc521)
		grep -q SM2_P256 <<<"$curves" && avail+=(ecc_sm2_p256)
	fi
	printf '%s\n' "${avail[@]}"
}

# Capture the EK currently persisted at 0x81010001.
# Sets EkName / EkFp / EkDesc; returns 1 when the handle is empty.
EkName="" EkFp="" EkDesc=""
read_current_ek() {
	EkName="" EkFp="" EkDesc=""
	local tmp
	tmp=$(mktemp -d) || return 1
	if ! tpm tpm2_readpublic -c "$EkHandle" -o "$tmp/ek.pem" -f pem -n "$tmp/ek.name" >"$tmp/ek.yaml" 2>/dev/null; then
		rm -rf "$tmp"
		return 1
	fi
	EkName=$(xxd -p "$tmp/ek.name" 2>/dev/null | tr -d '\n')
	if [[ -s $tmp/ek.pem ]]; then
		EkFp=$(openssl pkey -pubin -in "$tmp/ek.pem" -outform DER 2>/dev/null | sha256sum | cut -d' ' -f1)
		EkDesc=$(openssl pkey -pubin -in "$tmp/ek.pem" -text -noout 2>/dev/null | head -1 | sed 's/^ *//')
	fi
	mkdir -p "$ArtifactDir"
	cp -f "$tmp/ek.pem" "$ArtifactDir/ek-current.pem" 2>/dev/null
    cp -f "$tmp/ek.yaml" "$ArtifactDir/ek-current.yaml" 2>/dev/null
	rm -rf "$tmp"
	return 0
}

print_ek() {
	if read_current_ek; then
		printf '  EK @ %s\n' "$EkHandle"
		printf '    TPM Name    : %s\n' "${EkName:-?}"
		printf '    pubkey sha256: %s\n' "${EkFp:-?}"
		printf '    key         : %s\n' "${EkDesc:-?}"
	else
		printf '  EK @ %s: %s(no object persisted there)%s\n' "$EkHandle" "$C_DIM" "$C_RESET"
	fi
}

# ---------------------------------------------------------------- preflight ---

preflight() {
	rule
	printf '%sPhysical TPM%s\n' "$C_BOLD" "$C_RESET"
	printf '  device   : %s\n' "$TpmDev"
	printf '  hardware : %s\n' "$(readlink -f /sys/class/tpm/"$(basename "${TpmDev/tpmrm/tpm}")"/device 2>/dev/null || echo '?')"
	local mfg
	mfg=$(tpm tpm2_getcap properties-fixed 2>/dev/null |
		awk '/^TPM2_PT_MANUFACTURER:/{f=1;next} f&&/value:/{gsub(/"/,"",$2);print $2;exit}')
	printf '  vendor   : %s\n' "${mfg:-?}"
	echo
	print_ek
	echo
	printf '%sHierarchy state%s\n' "$C_BOLD" "$C_RESET"
	local lockset disable inlock
	lockset=$(perm_flag lockoutAuthSet)
	disable=$(perm_flag disableClear)
	inlock=$(perm_flag inLockout)
	printf '  lockoutAuthSet : %s%s\n' "${lockset:-?}" \
		"$([[ ${lockset:-0} == 1 ]] && echo '   <- tpm2_clear will need the lockout password' || echo '')"
	printf '  disableClear   : %s%s\n' "${disable:-?}" \
		"$([[ ${disable:-0} == 1 ]] && echo '   <- clear is BLOCKED until a reboot/platform reset' || echo '')"
	printf '  inLockout      : %s\n' "${inlock:-?}"
	echo
	printf '%sPersistent handles that TPM2_Clear will destroy%s\n' "$C_BOLD" "$C_RESET"
	tpm tpm2_getcap handles-persistent 2>/dev/null | sed 's/^/  /' || echo "  (none)"
	echo
	printf '%sCollateral damage check%s\n' "$C_BOLD" "$C_RESET"
	local luks=0 d
	for d in $(lsblk -rno NAME,FSTYPE 2>/dev/null | awk '$2=="crypto_LUKS"{print "/dev/"$1}'); do
		if cryptsetup luksDump "$d" 2>/dev/null | grep -qi systemd-tpm2; then
			fail "  $d is unlocked by this TPM -- clearing it makes the host UNBOOTABLE."
			luks=1
		fi
	done
	((luks == 0)) && good "  no TPM-sealed LUKS volumes on this host"
	local ntfs
	ntfs=$(blkid -t TYPE=ntfs -o device 2>/dev/null | wc -l)
	if ((ntfs > 0)); then
		warn "  $ntfs NTFS partition(s) present. Any BitLocker volume that unlocks"
		warn "  via this TPM will demand its recovery key after a clear."
	fi
	warn "  The manufacturer EK certificate in NV will no longer match the new EK."
	warn "  Attestation that validates the EK cert chain can detect that."
	rule
}

show_history() {
	echo
	printf '%sRe-provision history%s\n' "$C_BOLD" "$C_RESET"
	if [[ -s $HistoryLog ]]; then
		printf '  %s%-19s %-8s %-10s %-7s %s%s\n' "$C_DIM" "WHEN" "HASH" "KEY" "CLEARED" "RESULT" "$C_RESET"
		awk -F'\t' '{printf "  %-19s %-8s %-10s %-7s %s\n", $1, $2, $3, $4, $7}' "$HistoryLog"
		printf '  %stotal runs: %s%s\n' "$C_DIM" "$(wc -l <"$HistoryLog")" "$C_RESET"
	else
		printf '  %s(none recorded by this tool)%s\n' "$C_DIM" "$C_RESET"
	fi
}

# ------------------------------------------------------------------- probe ---

# Creates transient primaries only -- no NV writes, no clear, nothing
# persisted. Safe to run as often as you like.
probe_algorithms() {
	local tmp hashes keyalgs h k rc
	mapfile -t hashes < <(supported_hashes)
	mapfile -t keyalgs < <(supported_keyalgs)
	tmp=$(mktemp -d) || return 1

	echo
	rule
	printf '%sAlgorithm probe%s  %s(transient keys only -- nothing is written)%s\n' \
		"$C_BOLD" "$C_RESET" "$C_DIM" "$C_RESET"
	rule
	printf '  advertised hashes : %s\n' "${hashes[*]:-none}"
	printf '  advertised keys   : %s\n' "${keyalgs[*]:-none}"
	echo
	local ok_h=0 ok_k=0
	printf '  %sHash algorithms (key held at rsa2048)%s\n' "$C_BOLD" "$C_RESET"
	for h in "${hashes[@]}"; do
		if tpm tpm2_createprimary -C e -g "$h" -G rsa2048 -c "$tmp/p.ctx" >/dev/null 2>&1; then
			printf '    %sPASS%s  -g %s\n' "$C_GREEN" "$C_RESET" "$h"
			((ok_h++))
		else
			printf '    %sFAIL%s  -g %s\n' "$C_RED" "$C_RESET" "$h"
		fi
		tpm tpm2_flushcontext -t >/dev/null 2>&1
	done
	echo
	printf '  %sKey algorithms (hash held at sha256)%s\n' "$C_BOLD" "$C_RESET"
	for k in "${keyalgs[@]}"; do
		# Large RSA can take a while on an fTPM; show progress on a terminal,
		# but never emit bare \r into a pipe or log (it would double the line).
		[[ -t 1 ]] && printf '    %s... -G %s%s' "$C_DIM" "$k" "$C_RESET"
		if tpm tpm2_createprimary -C e -g sha256 -G "$k" -c "$tmp/p.ctx" >/dev/null 2>&1; then
			[[ -t 1 ]] && printf '\r\033[K'
			printf '    %sPASS%s  -G %s\n' "$C_GREEN" "$C_RESET" "$k"
			((ok_k++))
		else
			[[ -t 1 ]] && printf '\r\033[K'
			printf '    %sFAIL%s  -G %s\n' "$C_RED" "$C_RESET" "$k"
		fi
		tpm tpm2_flushcontext -t >/dev/null 2>&1
	done
	rm -rf "$tmp"

	echo
	rule
	printf '%sHow many identities this buys you%s\n' "$C_BOLD" "$C_RESET"
	printf '  %d hashes x %d key algs = %s%d distinct EKs%s reachable WITHOUT a clear.\n' \
		"$ok_h" "$ok_k" "$C_BOLD" "$((ok_h * ok_k))" "$C_RESET"
	cat <<'EOS'
  A primary key is derived deterministically from (seed, template), so:
    - a different -g/-G pair gives a different EK with no tpm2_clear at all
      (only the evictcontrol NV write) -- this is the cheap move;
    - repeating a pair you already used regenerates the SAME key, wasting a
      write for nothing -- check the history table before picking;
    - tpm2_clear re-rolls the seed, so the whole grid above becomes a fresh
      set of identities. That is the expensive, finite operation.
EOS
	rule
	info "PASS entries are safe to pick when re-provisioning."
	warn "MD5 is not a TPM algorithm -- it can never appear here; the error you"
	warn "saw on Mint was that, not a hardware limit. \"sh1\" is likewise a typo"
	warn "for sha1, so that step silently kept the previous key."
	return 0
}

# ------------------------------------------------------------ reprovision ---

reprovision() {
	local hashes keyalgs h k i choice
	mapfile -t hashes < <(supported_hashes)
	mapfile -t keyalgs < <(supported_keyalgs)
	((${#hashes[@]} && ${#keyalgs[@]})) || {
		fail "could not read supported algorithms from the TPM."
		return 1
	}

	echo
	printf '%sName/hash algorithm (-g)%s\n' "$C_BOLD" "$C_RESET"
	for i in "${!hashes[@]}"; do printf '  %d) %s\n' "$((i + 1))" "${hashes[i]}"; done
	read -r -p "  > [1] " choice
	choice=${choice:-1}
	[[ $choice =~ ^[0-9]+$ ]] && ((choice >= 1 && choice <= ${#hashes[@]})) || { fail "bad choice."; return 1; }
	h=${hashes[choice - 1]}

	echo
	printf '%sKey algorithm (-G)%s\n' "$C_BOLD" "$C_RESET"
	for i in "${!keyalgs[@]}"; do printf '  %d) %s\n' "$((i + 1))" "${keyalgs[i]}"; done
	read -r -p "  > [1] " choice
	choice=${choice:-1}
	[[ $choice =~ ^[0-9]+$ ]] && ((choice >= 1 && choice <= ${#keyalgs[@]})) || { fail "bad choice."; return 1; }
	k=${keyalgs[choice - 1]}

	local do_clear lockauth=""
	echo
	read -r -p "$(printf '%sRun tpm2_clear first? Without it the EPS is unchanged and the new EK may repeat. [Y/n] %s' "$C_BOLD" "$C_RESET")" do_clear
	do_clear=${do_clear:-Y}
	if [[ ${do_clear,,} =~ ^y ]]; then
		do_clear=yes
		if [[ $(perm_flag disableClear) == 1 ]]; then
			fail "disableClear is set -- TPM2_Clear is blocked until a platform reset."
			return 1
		fi
		if [[ $(perm_flag lockoutAuthSet) == 1 ]]; then
			warn "This TPM has a lockout password set; tpm2_clear needs it."
			read -r -s -p "  lockout auth (blank to try empty): " lockauth
			echo
		fi
	else
		do_clear=no
	fi

	read_current_ek || true
	local old_name=${EkName:-none} old_fp=${EkFp:-none}

	echo
	rule
	printf '%sPlan%s\n' "$C_BOLD" "$C_RESET"
	printf '  device      : %s\n' "$TpmDev"
	printf '  hash (-g)   : %s\n' "$h"
	printf '  key  (-G)   : %s\n' "$k"
	printf '  tpm2_clear  : %s\n' "$do_clear"
	printf '  persist at  : %s\n' "$EkHandle"
	printf '  current EK  : %s\n' "$old_name"
	rule
	fail "THIS MODIFIES THE PHYSICAL TPM. It is not undoable -- the old EK is"
	fail "derived from a seed that TPM2_Clear destroys. It writes NV flash, which"
	fail "has finite endurance. Do not do this casually."
	echo
	warn "Fidelity note: a plain createprimary object carries"
	warn "  fixedtpm|fixedparent|sensitivedataorigin|userwithauth|restricted|decrypt (0x30072)"
	warn "while a genuine TCG endorsement key carries"
	warn "  fixedtpm|fixedparent|sensitivedataorigin|adminwithpolicy|restricted|decrypt (0x300b2)."
	warn "Software that checks EK attributes or the EK policy can tell the difference."
	echo
	read -r -p "$(printf '%sType %sREPROVISION%s to proceed: %s' "$C_BOLD" "$C_RED" "$C_RESET$C_BOLD" "$C_RESET")" choice
	if [[ $choice != REPROVISION ]]; then
		info "Aborted -- the TPM was not touched."
		return 1
	fi

	local tmp step_rc=0 results=() ctx
	tmp=$(mktemp -d) || return 1
	ctx="$tmp/primary.ctx"

	run_step() {
		local label=$1
		shift
		[[ -t 1 ]] && printf '  %s... %s%s' "$C_DIM" "$label" "$C_RESET"
		if "$@" >"$tmp/out" 2>&1; then
			[[ -t 1 ]] && printf '\r\033[K'
			printf '  %sPASS%s %s\n' "$C_GREEN" "$C_RESET" "$label"
			results+=("PASS  $label")
			return 0
		fi
		[[ -t 1 ]] && printf '\r\033[K'
		printf '  %sFAIL%s %s\n' "$C_RED" "$C_RESET" "$label"
		sed 's/^/        /' "$tmp/out"
		results+=("FAIL  $label")
		return 1
	}

	echo
	rule
	if [[ $do_clear == yes ]]; then
		if [[ -n $lockauth ]]; then
			run_step "tpm2_clear -c l (with lockout auth)" tpm tpm2_clear -c l "$lockauth" || step_rc=1
		else
			run_step "tpm2_clear -c l" tpm tpm2_clear -c l || step_rc=1
		fi
		if ((step_rc)); then
			fail "clear failed -- stopping before touching the EK handle."
			rm -rf "$tmp"
			printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$(date -Is)" "$h" "$k" "$do_clear" \
				"$old_name" "-" "ABORTED_AT_CLEAR" >>"$HistoryLog"
			return 1
		fi
	fi

	if ! run_step "tpm2_createprimary -C e -g $h -G $k" \
		tpm tpm2_createprimary -C e -g "$h" -G "$k" -c "$ctx"; then
		fail "this algorithm combination is not usable on this chip."
		warn "Run the probe first to see which combinations PASS."
		rm -rf "$tmp"
		printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$(date -Is)" "$h" "$k" "$do_clear" \
			"$old_name" "-" "FAILED_CREATEPRIMARY" >>"$HistoryLog"
		return 1
	fi

	mkdir -p "$ArtifactDir"
	run_step "tpm2_readpublic -> endorsement_pub.pem" \
		tpm tpm2_readpublic -c "$ctx" -o "$ArtifactDir/endorsement_pub.pem" -f pem || true

	# Evict whatever is already sitting on the handle, else the persist fails.
	if tpm tpm2_readpublic -c "$EkHandle" >/dev/null 2>&1; then
		run_step "evict old object from $EkHandle" \
			tpm tpm2_evictcontrol -C o -c "$EkHandle" || true
	fi

	if ! run_step "tpm2_evictcontrol -C o -c primary.ctx $EkHandle" \
		tpm tpm2_evictcontrol -C o -c "$ctx" "$EkHandle"; then
		fail "could not persist the new EK."
		rm -rf "$tmp"
		printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$(date -Is)" "$h" "$k" "$do_clear" \
			"$old_name" "-" "FAILED_EVICTCONTROL" >>"$HistoryLog"
		return 1
	fi
	tpm tpm2_flushcontext -t >/dev/null 2>&1
	rm -rf "$tmp"
	rule

	echo
	printf '%sStep results%s\n' "$C_BOLD" "$C_RESET"
	printf '  %s\n' "${results[@]}"

	read_current_ek || true
	echo
	rule
	printf '%sIdentity diff%s\n' "$C_BOLD" "$C_RESET"
	printf '  %-14s %s\n' "old Name:" "$old_name"
	printf '  %-14s %s\n' "new Name:" "${EkName:-?}"
	printf '  %-14s %s\n' "old pubkey:" "$old_fp"
	printf '  %-14s %s\n' "new pubkey:" "${EkFp:-?}"
	printf '  %-14s %s\n' "new key:" "${EkDesc:-?}"
	if [[ -n ${EkName:-} && ${EkName:-} != "$old_name" ]]; then
		good "  EK CHANGED -- the host now presents a different TPM identity."
	else
		fail "  EK did NOT change. Nothing gained; do not repeat blindly."
	fi
	rule

	printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$(date -Is)" "$h" "$k" "$do_clear" \
		"$old_name" "${EkName:-none}" \
		"$([[ -n ${EkName:-} && ${EkName:-} != "$old_name" ]] && echo CHANGED || echo UNCHANGED)" \
		>>"$HistoryLog"
	good "recorded in $HistoryLog"
	info "Artifacts in $ArtifactDir (endorsement_pub.pem, ek-current.pem)"
	echo
	warn "Reboot into Windows to read the new TPM identity there."
	return 0
}

# -------------------------------------------------------------------- main ---

command -v tpm2 >/dev/null || {
	fail "tpm2-tools not installed (pacman -S tpm2-tools)."
	pause_exit 1
}
command -v openssl >/dev/null || warn "openssl missing -- pubkey fingerprints will be blank."
pick_device || {
	fail "no physical TPM under /sys/class/tpm. Enable it in firmware."
	pause_exit 1
}

clear 2>/dev/null || true
printf '%s' "$C_BOLD"
cat <<'BANNER'
==============================================================
        PHYSICAL TPM  -  endorsement key re-provision
             (host hardware identity, NOT the vTPM)
==============================================================
BANNER
printf '%s' "$C_RESET"
preflight
show_history

while true; do
	echo
	printf '%sWhat do you want to do?%s\n' "$C_BOLD" "$C_RESET"
	printf '  1) Probe algorithm support   %s(safe -- writes nothing)%s\n' "$C_DIM" "$C_RESET"
	printf '  2) Show current EK + history again\n'
	printf '  3) %sRE-PROVISION the physical TPM EK%s   %s(destructive, finite writes)%s\n' \
		"$C_RED" "$C_RESET" "$C_DIM" "$C_RESET"
	printf '  4) Quit without changing anything\n'
	read -r -p "  > [4] " Action
	case ${Action:-4} in
	1) probe_algorithms ;;
	2)
		preflight
		show_history
		;;
	3) reprovision && pause_exit 0 ;;
	4)
		info "Nothing changed."
		pause_exit 0
		;;
	*) fail "Enter 1-4." ;;
	esac
done
