OpenCore 1.0.8 release binaries and sample configuration.
Includes the captured boot image and shared-store driver media; the desktop creates a private writable boot copy.
Source: https://github.com/acidanthera/OpenCorePkg/tree/1.0.8
